<html>
<body>
    <a href="index.html" class="brand-logo">
        <img src="009_new.jpg" alt="">
    </a>
</body>
</html>