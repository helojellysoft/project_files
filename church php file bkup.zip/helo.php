<html>
<?php  
include("sidenav.php");
?>
                <div class="row">
                  <div class="col-12 grid-margin">
                   <div class="card">
                    <div class="card-body">
                     <h4 class="card-title"><div align="center">FAMILY MEMEBER</div></h4>
                     <form class="form-sample">
                       <div class="row">
                         <div class="col-md-6">
                           <div class="form-group row">
                             <label class="col-sm-3 col-form-label">F.No</label>
                           <div class="col-sm-3">
                            <input type="text" class="form-control" id="fno" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">S/No</label>
                          <div class="col-sm-3">
                            <input type="text" class="form-control" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                    	<div class="col-md-6">
                    		<div class="form-group row">
                    			<label class="col-sm-3 col-form-label">street</label>
                    			<div class="col-sm-7">
                    				<input type="text" class="form-control">
                    			</div>
                    		</div>
                    	</div>
                    	<div class="col-md-6">
                    		<div class="form-group row">
                    			<label class="col-sm-3 col-form-label">District</label>
                    			<div class="col-sm-7">
                    				<input type="text" class="form-control">
                    			</div>
                    		</div>
                    	</div>
                    </div>
                    <div class="row">
                    	<div class="col-md-6">
                    		<div class="form-group row">
                    			<label class="col-sm-3 col-form-label">Name</label>
                    			<div class="col-sm-7">
                    				<input type="text" class="form-control">
                    			</div>
                    		</div>
                    	</div>
                    	<div class="col-md-6">
                    		<div class="form-group row">
                               <label for="inputDate" class="col-sm-3 col-form-label">DOB</label>
                               <div class="col-sm-7">
                                   <input type="date" class="form-control">
                               </div>
                           </div>
                       </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Gender</label>
                          <div class="col-sm-7">
                            <select class="form-control">
                              <option>Male</option>
                              <option>Female</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Type</label>
                          <div class="col-sm-7">
                            <select class="form-control">
                              <option>S/off</option>
                              <option>w/off</option>
                              <option>d/off</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Relationship</label>
                          <div class="col-sm-7">
                            <select class="form-control">
                              <option>Grandpa</option>
                              <option>Father</option>
                              <option>Mother</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                    		<div class="form-group row">
                    			<label class="col-sm-3 col-form-label">Occupation</label>
                    			<div class="col-sm-7">
                    				<input type="text" class="form-control">
                    			</div>
                    		</div>
                    	</div>
                    </div>
                    <div class="row">
                    	<div class="col-md-6">
                    		<div class="form-group row">
                               <label for="inputDate" class="col-sm-3 col-form-label">D.O Baphism</label>
                               <div class="col-sm-7">
                                   <input type="date" class="form-control">
                               </div>
                           </div>
                       </div>
                    	<div class="col-md-6">
                    		<div class="form-group row">
                               <label for="inputDate" class="col-sm-3 col-form-label">D.O Marriage</label>
                               <div class="col-sm-7">
                                   <input type="date" class="form-control">
                               </div>
                           </div>
                       </div>
                    </div>
                    <div class="row">
                    	<div class="col-md-6">
                    		<div class="form-group row">
                               <label for="inputDate" class="col-sm-3 col-form-label">D.O Joining</label>
                               <div class="col-sm-7">
                                   <input type="date" class="form-control">
                               </div>
                           </div>
                       </div>
                    	<div class="col-md-6">
                    		<div class="form-group row">
                    			<label class="col-sm-3 col-form-label">Photo</label>
                    			<div class="col-sm-7">
                    				<input type="text" class="form-control">
                    			</div>
                    		</div>
                    	</div>
                    </div>
                    <div class="row">
                    	<div class="col-md-6">
                    		<div class="form-group row">
                    			<label class="col-sm-3 col-form-label">Mobile No</label>
                    			<div class="col-sm-7">
                    				<input type="text" class="form-control">
                    			</div>
                    		</div>
                    	</div>
                    	<div class="col-md-6">
                    		<div class="form-group row">
                    			<label class="col-sm-3 col-form-label">Aadther</label>
                    			<div class="col-sm-7">
                    				<input type="text" class="form-control">
                    			</div>
                    		</div>
                    	</div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Save</label>
                          <div class="col-sm-4">
                            <div class="form-check">
                              <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios1" value="" checked>
                                Yes
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-5">
                            <div class="form-check">
                              <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios2" value="option2">
                                No
                              </label>
                            </div>
                          </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-10">
                                <button type="submit" class="btn btn-primary">Next</button>
                            </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
                </html>
<script>
    $(document).ready(function(){
       $("#fno").focus();
    });
</script>