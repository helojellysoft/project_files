<ul class="metismenu" id="menu">
					<li class="nav-label first">Main Menu</li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-144-layout"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        <ul aria-expanded="false">
							<!-- <li><a href="index.html"> Light</a></li> -->
							<!-- <li><a href="index-2.html">Dashboard Dark</a></li>
							<li><a href="my-wallets.html">Wallet</a></li>
							<li><a href="tranasactions.html">Transactions</a></li>
							<li><a href="coin-details.html">Coin Details</a></li>
							<li><a href="portofolio.html">Portofolio</a></li>
							<li><a href="market-capital.html">Market Capital</a></li> -->
						</ul>

                    </li>
					<li class="nav-label">MEMBERS</li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-053-heart"></i>
							<span class="nav-text">Family Member</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="family_member_list.php">Edit/Delete</a></li>
                            <li><a href="family_member.php">New Family</a></li>
                        </ul>
                    </li>
					<li class="nav-label">ATTANDANCE</li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-044-file"></i>
							<span class="nav-text">Attandance</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="attend.php">Entry Page</a></li>
                            <li><a href="attend_update.php">Edit/Delete</a></li>
                        </ul>

                    </li>
                    <li class="nav-label">BALANCE SHEET</li>                        
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-061-puzzle"></i>
							<span class="nav-text">Receipt</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="receipt_entry.php">New Receipt </a></li>
                            <li><a href="receipt_list.php">Report</a></li>                      
                        </ul>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-061-puzzle"></i>
							<span class="nav-text">Receipt</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="receipt_entry.php">New Receipt </a></li>
                            <li><a href="receipt_list.php">Report</a></li>                      
                        </ul>
                    </li>
                    <!-- <li><a href="widget-basic.html" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Widget</span>
						</a>
					</li> -->
                    <!-- <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-044-file"></i>
							<span class="nav-text">Forms</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="form-element.html">Form Elements</a></li>
                            <li><a href="form-wizard.html">Wizard</a></li>
                            <li><a href="form-editor-summernote.html">Summernote</a></li>
                            <li><a href="form-pickers.html">Pickers</a></li>
                            <li><a href="form-validation-jquery.html">Jquery Validate</a></li>
                        </ul>
                    </li> -->
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Voucher</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="voucher_entry.php">New Voucher</a></li>
                            <li><a href="voucher_list.php">Edit/Delete</a></li>
                        </ul>
                    </li>
                    <li class="nav-label">EVENTS</li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-044-file"></i>
							<span class="nav-text"> EVENTS</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="events_entry.php">NEW Entry</a></li>        
                            <li><a href="events_list.php">Edit/Delete</a></li>
                            <li><a href="events_report.php">Weekly/Monthly</a></li>                            
                            <!-- <li><a href="ui-alert.html">Edit/Delete</a></li> -->
                        </ul>

                    </li>



                    <!-- <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-049-copy"></i>
							<span class="nav-text">Pages</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="page-register.html">Register</a></li>
                            <li><a href="page-login.html">Login</a></li>
                            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Error</a>
                                <ul aria-expanded="false">
                                    <li><a href="page-error-400.html">Error 400</a></li>
                                    <li><a href="page-error-403.html">Error 403</a></li>
                                    <li><a href="page-error-404.html">Error 404</a></li>
                                    <li><a href="page-error-500.html">Error 500</a></li>
                                    <li><a href="page-error-503.html">Error 503</a></li>
                                </ul>
                            </li>
                            <li><a href="page-lock-screen.html">Lock Screen</a></li>
                        </ul>
                    </li> -->
                </ul>
                