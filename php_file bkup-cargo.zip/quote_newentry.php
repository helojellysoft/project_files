<!doctype html>
<html class="no-js" lang="en">
 <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  </head>
<body>
    <?php
    include("nav.php");
    ?>
       
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
  </body>
  <body>
    <!-- <center> -->
<div class="alert alert-primary" role="alert">
  QUOTATION TITLE:    <input type="text" class="form-control" id="e1">

</div>
<!-- </center> -->
<div class="alert alert-secondary" role="alert">
    <center>
 Please fill in the information below.The field labels marked with* are required input fields.</center>
</div>

<div class="alert alert-success" role="alert" style="background-color:#FAD8BA">
  <div class="container overflow-hidden">
  <div class="row">
    <div class="col">
    Date :
   <input type="date" class="form-control" value="<?php echo date('Y-m-d'); ?>" id="date">
  </div>

  <div class="col">
    Invoice No :
   <input type="text" class="form-control" id="ino">
  </div>
  </div>
</div>
</div>
</div>

 <div class="alert alert-success" role="alert">
  <div class="container overflow-hidden">
  <div class="row">
    <div class="col">
    Particular :
   <input type="text" class="form-control" id="particular">
  </div>
<div class="col">
       Amount :
    <input type="text" class="form-control" id="amount">
</div>
<div class="col">
  <br>
  <input class="btn btn-primary" type="submit" value="Next" id="save">
</div>
</div>
</div>
</div>
<br>
<br>
<div class="alert alert-danger" role="alert">
  <table class="table" id="table1">
  <thead>
    <tr>
      <th scope="col">S.No</th>
      <th scope="col">Particular</th>
      <th scope="col">Amount</th>
       <th scope="col">DELETE</th>
     </tr>
  </thead>
  <tbody id="tbody">
    <!--tr>
      <td></td>
      <td></td>
      <td></td>
      <td><span class="material-symbols-outlined" style="font-size: 2em;"> delete </span></td>
     </tr>-->
  </tbody>
</table>
</div>
<!--   <div class="col">
    <br>
  <center><input class="btn btn-primary" type="submit" value="Submit" id="btnsubmit">
<input class="btn btn-primary" type="reset" value="Reset"></center>
</div>
 --></body>
<br>
<?php
// include("fotter1.php");
?>

<div class="alert alert-success" role="alert" style="background-color: #DAF7A6 ">
  <div class="container overflow-hidden">
  <div class ="row">
  <div class="col">
    Particular :
   <input type="text" class="form-control" id="particular1">
  </div>
<div class="col"> 
       Amount :
    <input type="text" class="form-control" id="amount1">
</div>
<div class="col">
  <br>
  <input class="btn btn-primary" type="submit" value="Next" id="save1">
</div>
</div>
</div>
</div>
<br>
<br>
<div class="alert alert-danger" role="alert" style="background-color:#CAE2F9">
  <table class="table" id="table2">
  <thead>
    <tr>
      <th scope="col">S.No</th>
      <th scope="col">Particular</th>
      <th scope="col">Amount</th>
      <th scope="col">DELETE</th>
     </tr>
  </thead>
  <tbody id="tbody1">
    <!--tr>
      <td></td>
      <td></td>
      <td></td>
      <td><span class="material-symbols-outlined" style="font-size: 2em;"> delete </span></td>
    </tr>-->
    
  </tbody>
</table>
</div>
<div class="alert alert-primary" role="alert">
   TITLE 1:    <input type="text" class="form-control" id="e2">

</div>
<div class="alert alert-primary" role="alert">
   TITLE 2:    <input type="text" class="form-control" id="e3">

</div>

<div class="col">
    <br>
  <center><input class="btn btn-primary" type="submit" value="Submit" id="btnsubmit">
<input class="btn btn-primary" type="reset" value="Reset"></center>
</div>
</body>
<br>
<?php
include("fotter.php");
?>
</html>
<script type="text/javascript">
  $(document).ready(function(){
    var s=0;
    var s1=0;    
    $("#save").click(function(){
       s=s+1;
      var  count = $('#table1 tr').length;       
      var particular = $("#particular").val();
      var amount = $("#amount").val();
      
      var x = "<tr id='tdfirst'><td>"+count+"</td><td class='c1'>"+particular+"</td><td class='c2'>"+amount+"</td><td><span class='material-symbols-outlined' style='font-size: 2em;' id='del'> delete </span></td></tr>";
      $("#tbody").append(x);

      $("#particular").val("");
      $("#amount").val("");
      $("#particular").focus();
    });
    $("#save1").click(function(){
      var  count = $('#table2 tr').length;      
      var particular1 = $("#particular1").val();
      var amount1 = $("#amount1").val();
       s1=s1+1;
      var x1 = "<tr id='tdfirst1'><td>"+count+"</td><td class='d1'>"+particular1+"</td><td class='d2'>"+amount1+"</td><td><span class='material-symbols-outlined' style='font-size: 2em;' id='del1'> delete </span></td></tr>";
      $("#tbody1").append(x1);
      
      $("#particular1").val("");
      $("#amount1").val("");
      $("#particular1").focus();
    });
  });
</script>
<script type="text/javascript">
  //$(document).ready(function(){
    //$('#del').click(function(){
      //alert("hello");
    //});

  //});
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $("#btnsubmit").click(function(){
      

      var jqdate = $("#date").val();
      var jqino = $("#ino").val();
      var jqparticular = $("#particular").val();
      var jqamount = $("#amount").val();
      var e1=$("#e1").val();
      var e2=$("#e2").val();
      var e3=$("#e3").val();


      // $("#date").val("");
      // $("#ino").val("");
      // $("#particular").val("");
      // $("#amount").val("");
      // $("#date").focus();
      
      
      $.ajax({
        url :"quote_entrysdata.php",
        method : "GET",
        data : {jqdate:jqdate, jqino:jqino, jqparticular:jqparticular, jqamount:jqamount, e1:e1, e2:e2, e3:e3},
        success : function(response){
          // alert("ajax working");
        }

      });


    });

  });
  
</script>
<script type="text/javascript">
  $(document).ready(function(){
    $("#btnsubmit").click(function(){

      var jaino = $("#ino").val();

      var ar1 = [];
      var ar2 = [];

      $(".c1").each(function(){
        ar1.push($(this).text());
      });

      $(".c2").each(function(){
        ar2.push($(this).text());
      })
      //alert(ar2);

      $.ajax({
        url : 'quote_entryadata.php',
        method : 'GET',
        data : {jaino:jaino, ar1:ar1, ar2:ar2},
        success : function(response){
          //alert("records collected");
        }

      });
    });
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $("#btnsubmit").click(function(){

      var jaino = $("#ino").val();
      // alert("invoice no: "+jaino);
      var arr1 = [];
      var arr2 = [];

      $(".d1").each(function(){
        arr1.push($(this).text());
      });

      $(".d2").each(function(){
        arr2.push($(this).text());
      })
      //alert(ar2);

      $.ajax({
        url : 'quote_entryasdata.php',
        method : 'GET',
        data : {jaino:jaino, arr1:arr1, arr2:arr2},
        success : function(response){
          //alert("records transfered");
          window.location.href='quote_display.php';          
        }

      });
    });
  });
</script>


<script>
$("table").on('click', '#tdfirst', function() {
  // alert("working");
    var currentRow = $(this).closest("tr");
    // alert("working");
    if (confirm('Are you sure ?')) {
        $(this).remove();        
    }
    var  count = $('#table1 tr').length;
    for(var i=0;i<count-1; i++){
    var x = document.getElementById("table1").rows[i+1].cells;
    x[0].innerHTML = i+1;
    }    

});
</script>
<script type="text/javascript">
$("table").on('click','#tdfirst1',function(){
// alert("working");
var currnetRow = $(this).closest("tr");
if(confirm('Are you sure?')){
  $(this).remove();
}
    var  count = $('#table2 tr').length;
    for(var i=0;i<count-1; i++){
    var x = document.getElementById("table2").rows[i+1].cells;
    x[0].innerHTML = i+1;
    }
});
</script>