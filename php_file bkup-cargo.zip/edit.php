<html>
<head>
<title></title>
</head>
<body>
<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
$pid=$_REQUEST['id'];
$qr=mysqli_query($conn,"select * from ship where sno='$pid'");
while($dt=mysqli_fetch_array($qr))
{
?>
<form action="editf.php" method="POST">
<input type="hidden" name="sno" value='<?php echo$dt['sno'];?>'>
	<div>name:<input type="text" name="name" value='<?php echo$dt['name'];?>'></div><br><br>
    <div>mobile:<input type="text" name="mobile" value='<?php echo$dt['mobile']; ?>'></div><br><br>
    <div>email:<input type="text" name="email" value='<?php echo$dt['email']; ?>'></div><br><br>
    <div>address:<input type="text" name="address" value='<?php echo$dt['address']; ?>'></div><br><br>
    <div>district:<input type="text" name="district" value='<?php echo$dt['district']; ?>'></div><br><br>
    <div>state:<input type="text" name="state" value='<?php echo$dt['state']; ?>'></div><br><br>
    <div>country:<input type="text" name="country" value='<?php echo$dt['country']; ?>'></div><br><br>
    <div>gst:<input type="text" name="gst" value='<?php echo$dt['gst']; ?>'></div><br><br>
    <div>remark:<input type="text" name="remark" value='<?php echo$dt['remark'];}?>'></div><br><br>
   <input type="submit" value="Change">
</form>
</body>
</html>
