
<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
$vname=$_POST['name'];
$vmobile=$_POST['mobile'];
$vemail=$_POST['email'];
$vaddress=$_POST['address'];
$vdistrict=$_POST['district'];
$vstate=$_POST['state'];
$vcountry=$_POST['country'];
$vgst=$_POST['gst'];
$vremark=$_POST['remark'];
$v1=$_POST['acname'];
$v2=$_POST['ccacno'];
$v3=$_POST['ifsc'];
$v4=$_POST['swiftcode'];
$v5=$_POST['adcode'];
$v6=$_POST['B_name'];
$v7=$_POST['B_address'];
$v8=$_POST['B_district'];
$v9=$_POST['B_state'];
$v10=$_POST['B_country'];
// echo"state:".$v9."Country".$v10;


$qr="Insert into ship1(name,mobile,email,address,district,state,country,gst,remark,ex_acname,ex_acno,ex_ifsc,ex_swiftcode,ex_adcode,ex_bankname,ex_bankaddress,ex_bankdist,ex_bankstate,ex_bankcountry)values('$vname','$vmobile','$vemail','$vaddress','$vdistrict','$vstate','$vcountry','$vgst','$vremark','$v1','$v2','$v3','$v4','$v5','$v6','$v7','$v8','$v9','$v10')";
// echo$qr;
if ($conn->query($qr)==True){
echo"Record ok inserted";
header("location:invoice_entry.php");
}else{
echo"Error:" .$qr."<br>". $conn->error;
}

?>