<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "insert";

$con2 = mysqli_connect("localhost", "root", "", "insert");
if($con2 == false){
	die("Error:Could'nt Connect".mysqli_connect_error());
}

$b1 = $_GET['jaino'];
$b2 = $_GET['arr1'];
$b3 = $_GET['arr2'];
for($i=0;$i<count($b2);$i=$i+1){
	//echo$b1[$i]."<br>";
	//echo$b2[$i];

	$sql2="insert into tblquote_details2(jasparticular,jasamount,jasino)values('$b2[$i]','$b3[$i]','$b1')";
	echo$sql2;

	$res2=mysqli_query($con2,$sql2);
}

?>