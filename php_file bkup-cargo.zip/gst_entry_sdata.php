
<?php
include'dbconfig.php';
$conn = opencon();
echo"db connected";
$vt1 = $_GET["gstbno"];
$vt2 = $_GET["g1"];				//bno1
$vt3 = $_GET['g2'];
$vt4 = $_GET['g3'];
// $vt5 = $_GET['jbpartsingle'];

// $ex1 = $_GET['jex1'];				//bno2
// $ex2 = $_GET['jex2'];
// $ex3 = $_GET['jex3'];				//bno3
// $ex4 = $_GET['jex4'];

$query="insert into tblgst(gstbno,sgst,cgst,igst)values ('$vt1','$vt2','$vt3','$vt4')";
echo$query;
$qrexe = $conn->query($query);



// echo"working";
// $query21="insert into tblin_pay_history(pdate,pbno,amt)value('$vt1,'$vt2','0')";;
// echo$query21;
// $qrexe21 = $conn->query($query21);

?>