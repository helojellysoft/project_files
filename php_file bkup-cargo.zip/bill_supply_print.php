<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
        <style>
          *{
            font-size: 12 px;
          }
          .pb{
            text-align-last: center;

          }
          .dtryt{
            float:right ;
          }
          .total{
  text-align: center;
  background-color: #7f7f7f;
}

.total{
  color: #000000;
  font-size: 18px;
  padding: 5px 0;
  display: inline-block;
  border-top: 1px solid #000000;
  border-bottom: 3px solid #000000;  
}

<header>
  <h1>HEADER</h1>
</header>

        </style>


  </head>
  <body>
    <h2 class="pb">Bill Of Supply<h2><br>
      <h2 class="pb">GSTIN:33AGPR7201R1ZQ</h2><br>
      <h4 class="dtryt">Date:23.03.23</h4>
      <h4>Bill No.DCM/2020-21/058</h4>
      <h4>To:M/s.DNM EXPORTS,CHENNAI.</h4>
      <h4>   GSTIN:33AHRPA9952D1ZA</h4>
      &nbsp;
      <h6>Shipped per: MV.OEL SHRAVAN VN20051</h6>
      <h6>Particulars Of Cargo: 104 Rolls - Non Woven Spunbond Hydrophoic Fabric Blue 20 GSM-1X20'FCL</h6>
      <h6>Under S.B/B.E.No.&Dt.3970272/21.07.20</h6>
      <h6>Invoice No.&Dt.DNM/023/20-21/20.07.20</h6>
      <hr style="border-bottom:solid dark blue 1px;">
    <table class="table">
  <thead>
    <tr>
      <th scope="col">SI(No.)</th>
      <th scope="col">particulars</th>
      <th scope="col">  </th>
      <th scope="col">Amount(Rs.ps)</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
    <tr>
      <th scope="row">1</th>
      <td>thc</td>
      <td>  </td>
      <td style="text-align: right;">5000.00</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>BL charges</td>
      <td>  </td>
      <td>3000.00</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Admin fee</td>
      <td>  </td>
      <td>500.00</td>
    </tr>
     <tr>
      <th scope="row"></th>
      <td></td>
      <td >Total</td>
      <td class="total">1971.18</td>
    </tr>
    </tbody>
</table>

  </tbody>
</table>
<h4 class="pb">R/off : Rs.19472.00</h4>
   <h5 class="pb"> (Rupess Nineteen Thousand,Four Hundred and seventy Two only)<h5>
          <hr style="border-bottom: 1px dashed darkblue;">


    
  </body>
</html>