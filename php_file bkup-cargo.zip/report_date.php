<!doctype html>
<html class="no-js" lang="en">

<head>
    <link rel="stylesheet" href="css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="css/data-table/bootstrap-editable.css">
    <!-- style CSS
        ============================================ -->
</head>
<style >
    .
</style>
<body>
    <?php
    include("nav.php");
    $server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
    ?>
        <!-- Static Table Start -->
<br><br>
        <div class="basic-form-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <div class="sparkline10-list mt-b-30" style="background-color: #A3E4D7">
                            <div class="sparkline10-hd">
                                <div class="main-sparkline10-hd">
                                    <h1>Quotation <span class="basic-ds-n"></span></h1>
                                </div>
                            </div>
                            <div class="sparkline10-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="basic-login-inner inline-basic-form">
                                                <form action="#">
                                                    <div class="form-group-inner">
                                                        <div class="row">
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" id ="fdate" style="background-color: #ABB2B9;border: 1px solid#808B96;" value="<?php echo date('Y-m-d'); ?>" class="form-control basic-ele-mg-b-10 responsive-mg-b-10" placeholder="From" />
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" style="background-color: #ABB2B9;border: 1px solid#808B96;" value="<?php echo date('Y-m-d'); ?>" class="form-control basic-ele-mg-b-10 responsive-mg-b-10" id="tdate" placeholder="To" />
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="login-btn-inner">
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-7 col-sm-7 col-xs-12">
                                                                <div class="inline-remember-me">
                                                                    <label>
                                                                            <input type="checkbox" class="i-checks">  </label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                                <div class="login-horizental lg-hz-mg"><button class="btn btn-sm btn-primary login-submit-cs" type="button" id="btnquote" style=" background-color: #ABB2B9; border: 2px solid#808B96; color: black;">Click here</button></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>



<!-- -------------------------------------------------------------------------------- -->
<br><br>
        <div class="basic-form-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <div class="sparkline10-list mt-b-30" style="background-color: #F9E79F">
                            <div class="sparkline10-hd">
                                <div class="main-sparkline10-hd">
                                    <h1>Invoice <span class="basic-ds-n"></span></h1>
                                </div>
                            </div>
                            <div class="sparkline10-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="basic-login-inner inline-basic-form">
                                                <form action="#">
                                                    <div class="form-group-inner">
                                                        <div class="row">
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" style="background-color: #D6EAF8;border:1px solid#82E0AA;" value="<?php echo date('Y-m-d'); ?>"  id="infdate"class="form-control basic-ele-mg-b-10 responsive-mg-b-10" placeholder="From" />
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" style="background-color: #D6EAF8;border: 1px solid#82E0AA;" value="<?php echo date('Y-m-d'); ?>" class="form-control basic-ele-mg-b-10 responsive-mg-b-10" id="intdate" placeholder="To" />
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="login-btn-inner">
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-7 col-sm-7 col-xs-12">
                                                                <div class="inline-remember-me">
                                                                    <label>
                                                                            <input type="checkbox" class="i-checks">  </label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                                <div class="login-horizental lg-hz-mg"><button class="btn btn-sm btn-primary login-submit-cs" type="button" id="btninvoice"style=" background-color: #D6EAF8; border: 2px solid#82E0AA;
                                                                color: black;">Click here</button></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

<!-- ------------------------------------------------------------------------ -->
<?php

$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);


?>
<br><br>
        <div class="basic-form-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <div class="sparkline10-list mt-b-30">
                            <div class="sparkline10-hd">
                                <div class="main-sparkline10-hd">
                                    <h1>Bill of Supply <span class="basic-ds-n"></span></h1>
                                </div>
                            </div>
                            <div class="sparkline10-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="basic-login-inner inline-basic-form">
                                                <form action="#">
                                                    <div class="form-group-inner">
                                                        <div class="row">
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" value="<?php echo date('Y-m-d'); ?>" id="bosfrom" class="form-control basic-ele-mg-b-10 responsive-mg-b-10" placeholder="From" />
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" value="<?php echo date('Y-m-d'); ?>" id="bosto" class="form-control basic-ele-mg-b-10 responsive-mg-b-10" placeholder="To" />
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="login-btn-inner">
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-7 col-sm-7 col-xs-12">
                                                                <div class="inline-remember-me">
                                                                <select name="" id="txtnongstparty" class="form-control basic-ele-mg-b-10 responsive-mg-b-10">
                                                                <option value="all">- Select Name -</option>
<?php 
$qr=mysqli_query($conn,"select * from ship1_party where name!=''");
while($dt=mysqli_fetch_array($qr))
{ 
    $t1 = $dt['name'];
?>

                                                                
                                                                <option value='<?php echo $t1; ?>'><?php echo$dt['name'];  } ?></option>

                                                                </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                                <div class="login-horizental lg-hz-mg"><button class="btn btn-sm btn-primary login-submit-cs" type="button" id="btnbos">Click here</button></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

 <br><br>
        <div class="basic-form-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <div class="sparkline10-list mt-b-30">
                            <div class="sparkline10-hd">
                                <div class="main-sparkline10-hd">
                                    <h1>Taxable <span class="basic-ds-n"></span></h1>
                                </div>
                            </div>
                            <div class="sparkline10-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="basic-login-inner inline-basic-form">
                                                <form action="#">
                                                    <div class="form-group-inner">
                                                        <div class="row">
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" id="taxfrom" value="<?php echo date('Y-m-d'); ?>" class="form-control basic-ele-mg-b-10 responsive-mg-b-10" placeholder="From" />
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" value="<?php echo date('Y-m-d'); ?>" id="taxto"class="form-control basic-ele-mg-b-10 responsive-mg-b-10" placeholder="To" />
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="login-btn-inner">
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-7 col-sm-7 col-xs-12">
                                                                <div class="inline-remember-me">
                                                                <select name="" id="txtgstparty" class="form-control basic-ele-mg-b-10 responsive-mg-b-10">
                                                                <option value="all">- Select Name -</option>
<?php 
$qr=mysqli_query($conn,"select * from ship1_party where name!=''");
while($dt=mysqli_fetch_array($qr))
{ 
    $t1 = $dt['name'];
?>

                                                                
                                                                <option value='<?php echo $t1; ?>'><?php echo$dt['name'];  } ?></option>

                                                                </select>

                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                                <div class="login-horizental lg-hz-mg"><button class="btn btn-sm btn-primary login-submit-cs" type="button" id="btntax">Click here</button></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div> 
<!-- ---------------------------------------------------------------------------------- -->
<br><br>
        <div class="basic-form-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <div class="sparkline10-list mt-b-30"style="background-color: #F5B7B1;">
                            <div class="sparkline10-hd">
                                <div class="main-sparkline10-hd">
                                    <h1>Incoming Payment <span class="basic-ds-n"></span></h1>
                                </div>
                            </div>
                            <div class="sparkline10-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="basic-login-inner inline-basic-form">
                                                <form action="#">
                                                    <div class="form-group-inner">
                                                        <div class="row">
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" style="background-color: #46A2FD;
                                                                border: 1px solid#2874A6;" value="  <?php echo date('Y-m-d'); ?>" id="ipfrom" class="form-control basic-ele-mg-b-10 responsive-mg-b-10" placeholder="From" />
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" id ="ipto" style="background-color: #46A2FD;border: 1px solid#2874A6;"value="<?php echo date('Y-m-d'); ?>" class="form-control basic-ele-mg-b-10 responsive-mg-b-10" placeholder="To" />
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="login-btn-inner">
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-7 col-sm-7 col-xs-12">
                                                                <div class="inline-remember-me">
                                                                    <label>
                                                                            <input type="checkbox" class="i-checks"> </label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                                <div class="login-horizental lg-hz-mg"><button class="btn btn-sm btn-primary login-submit-cs" type="button" id="btnip" style="background-color:#46A2FD; border: 2px solid#2874A6;color: black; " >Click here</button></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div> 
<br><br>
        <div class="basic-form-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <div class="sparkline10-list mt-b-30" style="background-color: #DFBAF6" >
                            <div class="sparkline10-hd">
                                <div class="main-sparkline10-hd">
                                    <h1>Outgoing Payment <span class="basic-ds-n"></span></h1>
                                </div>
                            </div>
                            <div class="sparkline10-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="basic-login-inner inline-basic-form">
                                                <form action="#">
                                                    <div class="form-group-inner">
                                                        <div class="row">
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" value="<?php echo date('Y-m-d'); ?>" id="opfrom" class="form-control basic-ele-mg-b-10 responsive-mg-b-10" placeholder="From" />
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" value="<?php echo date('Y-m-d'); ?>" id="opto" class="form-control basic-ele-mg-b-10 responsive-mg-b-10" placeholder="To" />
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="login-btn-inner">
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-7 col-sm-7 col-xs-12">
                                                                <div class="inline-remember-me">
                                                                    <label>
                                                                            <input type="checkbox" class="i-checks"> </label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                                <div class="login-horizental lg-hz-mg"><button class="btn btn-sm btn-primary login-submit-cs" type="button" id="btnop">Click here</button></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
<br><br>
        <div class="basic-form-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <div class="sparkline10-list mt-b-30" style="background-color: #A7FA88">
                            <div class="sparkline10-hd">
                                <div class="main-sparkline10-hd">
                                    <h1>Outgoing Register <span class="basic-ds-n"></span></h1>
                                </div>
                            </div>
                            <div class="sparkline10-graph">
                                <div class="basic-login-form-ad">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="basic-login-inner inline-basic-form">
                                                <form action="#">
                                                    <div class="form-group-inner">
                                                           <div class="row">
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" value="<?php echo date('Y-m-d'); ?>" id="orfrom" class="form-control basic-ele-mg-b-10 responsive-mg-b-10" placeholder="From" />
                                                            </div>
                                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                                                <input type="date" value="<?php echo date('Y-m-d'); ?>" class="form-control basic-ele-mg-b-10 responsive-mg-b-10" id="orto" placeholder="To" />
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="login-btn-inner">
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-7 col-sm-7 col-xs-12">
                                                                <div class="inline-remember-me">
                                                                    <label>
                                                                            <input type="checkbox" class="i-checks"> </label>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                                <div class="login-horizental lg-hz-mg"><button class="btn btn-sm btn-primary login-submit-cs" type="button" id="btnor">Click here</button></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>


    <script src="js/data-table/bootstrap-table.js"></script>
    <script src="js/data-table/tableExport.js"></script>
    <script src="js/data-table/data-table-active.js"></script>
    <script src="js/data-table/bootstrap-table-editable.js"></script>
    <script src="js/data-table/bootstrap-editable.js"></script>
    <script src="js/data-table/bootstrap-table-resizable.js"></script>
    <script src="js/data-table/colResizable-1.5.source.js"></script>
    <script src="js/data-table/bootstrap-table-export.js"></script>
    <!--  editable JS
        ============================================ -->
    <script src="js/editable/jquery.mockjax.js"></script>
    <script src="js/editable/mock-active.js"></script>
    <script src="js/editable/select2.js"></script>
    <script src="js/editable/moment.min.js"></script>
    <script src="js/editable/bootstrap-datetimepicker.js"></script>
    <script src="js/editable/bootstrap-editable.js"></script>
    <script src="js/editable/xediable-active.js"></script>
</body>
<?php
include("fotter.php");
?>
</html>
<script type="text/javascript">
    $(document).ready(function(){
        $("#btnquote").click(function(){
            var d1 = $("#fdate").val();
            var d2= $("#tdate").val();
            // alert(d2);
            window.location.href='quote_display_date.php?dt1=' +d1+'&dt2='+d2+'';
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#btninvoice").click(function(){
            var id1 = $("#infdate").val();
            var id2= $("#intdate").val();
            // alert(id2);
            window.location.href='invoice_display_date.php?idt1=' +id1+'&idt2='+id2+'';
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#btnbos").click(function(){
            var bd1 = $("#bosfrom").val();
            var bd2= $("#bosto").val();
            var bd3 = $("#txtnongstparty").val();
            //alert(bd3);
            window.location.href='nongst_filing_date.php?idt1=' +bd1+'&idt2='+bd2+'&idt3='+bd3+'';
        });
    });
</script>
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#btntax").click(function(){
            var td1 = $("#taxfrom").val();
            var td2= $("#taxto").val();
            var td3= $("#txtgstparty").val();            
            // alert(id2);
            window.location.href='gst_filing_date.php?idt1=' +td1+'&idt2='+td2+'&idt3='+td3+'';
        });
    });
</script>
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#btnip").click(function(){
            var ipd1 = $("#ipfrom").val();
            var ipd2= $("#ipto").val();
            // alert(id2);
            window.location.href='in_pay_display_date.php?idt1=' +ipd1+'&idt2='+ipd2+'';
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#btnop").click(function(){
            var opd1 = $("#opfrom").val();
            var opd2= $("#opto").val();
            // alert(id2);
            window.location.href='out_pay_display_date.php?idt1=' +opd1+'&idt2='+opd2+'';
        });
    });
</script>

<script type="text/javascript">
    $(document).ready(function(){
        $("#btnor").click(function(){
            var ord1 = $("#orfrom").val();
            var ord2= $("#orto").val();
            // alert(id2);
            window.location.href='outgoing_display_date.php?idt1=' +ord1+'&idt2='+ord2+'';
        });
    });
</script>