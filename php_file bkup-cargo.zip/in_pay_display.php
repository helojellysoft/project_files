<!doctype html>
<html class="no-js" lang="en">

<head>
    <link rel="stylesheet" href="css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="css/data-table/bootstrap-editable.css">
    <!-- style CSS
        ============================================ -->
</head>

<body>
    <?php
    include("nav.php");
    $server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
    ?>
        <!-- Static Table Start -->
        <div class="data-table-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline13-list">
                            <div class="sparkline13-hd">
                                <div class="main-sparkline13-hd">
                                    <h1>Incoming <span class="table-project-n">Payments</span> </h1>
                                </div>
                            </div>
                            <div class="sparkline13-graph">
                                <div class="datatable-dashv1-list custom-datatable-overright">
                                    <div id="toolbar">
                                        <select class="form-control dt-tb">
                                            <option value="">Export Basic</option>
                                            <option value="all">Export All</option>
                                            <option value="selected">Export Selected</option>
                                        </select>
                                    </div>
                                    <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true"
                                        data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                        <thead>
                        <tr>
                           <th data-field="name" data-editable="true">Inv.No</th>
                            <th data-field="email" data-editable="true">Date</th>
                            <th data-field="phone" data-editable="true">Shipper</th>
                            <th data-field="task" data-editable="true">Bill Amount</th>
                            <!-- <th data-field="date" data-editable="true">Inv.Date</th> -->
                            <th data-field="price" data-editable="true">Status</th>
                            <!-- <th data-field="a1" data-editable="true">Pay Mode</th> -->
                            <!-- <th data-field="a2" data-editable="true">Pay Date</th> -->
                            <!-- <th data-field="a3" data-editable="true">Remarks</th> -->
                             <th data-field="Edit">Action</th>
                             <th data-field="hist">View</th>                             
                            <th data-field="delete">Delete</th>
                        </tr>
                                        </thead>
                                        <tbody>
<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
$qr22=mysqli_query($conn,"SELECT ex_bno2,tbper, tbdate,tbto,ex_bno1 from tbltaxbill where ex_bno1!='' GROUP BY ex_bno1");
while($dt22=mysqli_fetch_array($qr22))
{
    $temp = $dt22['ex_bno1'];
$qr2=mysqli_query($conn,"select sum(tamt)as in_tot from tbltaxdetails where ex_bno1='$temp'");
while($dt2=mysqli_fetch_array($qr2))
{
    $tot = $dt2['in_tot'];
} 

$higst="select sum(igst+sgst+cgst)as in_gst from tblgst where gstbno='$temp'";

$qr2gst=mysqli_query($conn,$higst);    

while($dt2gst=mysqli_fetch_array($qr2gst))
{
    $tot1_gst = $tot * $dt2gst['in_gst']*0.01;
}    

$final_gst_amt = $tot1_gst +  $tot;    


$tqr2=mysqli_query($conn,"select sum(amt)as in_tot2 from tblin_pay_history where pbno='$temp'");
while($tdt2=mysqli_fetch_array($tqr2))
{

    $tot2 = $tdt2['in_tot2'];
}

$final_amt = $final_gst_amt - $tot2;



if($final_amt=='0'){
    $sts = "Paid";
}
else{
    $sts="Pending";
}
?>
                                            <tr>
                                                <td><?php echo $dt22['ex_bno2'];?></td>
                                                <td><?php echo $dt22['tbdate'];?></td>
<td><?php echo $temp;?></td>
<td><?php echo $final_amt; ?></td>
<td><?php echo $sts;?></td>
                                                     <td class="datatable-ct"><a href="in_pay_entry.php?id=<?php echo$temp;?>"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="20" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg></td>

<td class="datatable-ct"><a href="in_pay_display_hist.php?id=<?php echo$temp;?>"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="20" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg></td>

                                                       <td class="datatable-ct"><a href="delete_in_pay.php?id=<?php echo$dt['tbno'];?>"> <svg xmlns="http://www.w3.org/2000/svg" width="30" height="20" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
  <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z"/>
</svg>
                                                </td>
                                            </tr>
                                               <?php
}
?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    <script src="js/data-table/bootstrap-table.js"></script>
    <script src="js/data-table/tableExport.js"></script>
    <script src="js/data-table/data-table-active.js"></script>
    <script src="js/data-table/bootstrap-table-editable.js"></script>
    <script src="js/data-table/bootstrap-editable.js"></script>
    <script src="js/data-table/bootstrap-table-resizable.js"></script>
    <script src="js/data-table/colResizable-1.5.source.js"></script>
    <script src="js/data-table/bootstrap-table-export.js"></script>
    <!--  editable JS
        ============================================ -->
    <script src="js/editable/jquery.mockjax.js"></script>
    <script src="js/editable/mock-active.js"></script>
    <script src="js/editable/select2.js"></script>
    <script src="js/editable/moment.min.js"></script>
    <script src="js/editable/bootstrap-datetimepicker.js"></script>
    <script src="js/editable/bootstrap-editable.js"></script>
    <script src="js/editable/xediable-active.js"></script>
</body>
<?php
include("fotter.php");
?>
</html>