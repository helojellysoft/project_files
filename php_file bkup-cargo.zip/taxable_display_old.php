<!doctype html>
<html class="no-js" lang="en">

<head>
    <link rel="stylesheet" href="css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="css/data-table/bootstrap-editable.css">
    <!-- style CSS
        ============================================ -->
</head>

<body>
    <?php
    include("nav.php");
    $server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
    ?>
        <!-- Static Table Start -->
        <div class="data-table-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline13-list">
                            <div class="sparkline13-hd">
                                <div class="main-sparkline13-hd">
                                    <h1>Taxable <span class="table-project-n">Data</span> Table</h1>
                                                                        
                                </div>
                            </div>
                            <div class="sparkline13-graph">
                        <div class="datatable-dashv1-listcustom-datatable-overright">
                                    <div id="toolbar">
                                        <select class="form-control dt-tb">
                                            <option value="">Export Basic</option>
                                            <option value="all">Export All</option>
                                            <option value="selected">Export Selected</option>
                                        </select>
                                    </div>
                                    <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true"
                                        data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                        <thead>
                                            <tr>
                                               <th data-field="name" data-editable="true">Date</th>
                                                <th data-field="email" data-editable="true">Bill No</th>

                                                <th data-field="date" data-editable="true">Bill Amt</th>

                                                <th data-field="helo" data-editable="false">Letter Pad</th>
                                                <th data-field="duplic" data-editable="false">Duplicate</th>                                                

                                                <th data-field="helo2" data-editable="false">Normal</th>                                                
                                                <th data-field="price" data-editable="false">Delete</th>
                                            </tr>
                                        </thead>
                                        <tbody style="color:black;">
<?php
$i="select * from tbltaxable_temp ";
// $ir=mysqli_query($conn,$i);
// while($it=mysqli_fetch_array($ir))
// {
//     $va = $it['temp_bno'];

$qr=mysqli_query($conn,"select * from tbltaxbill where ex_status='1'");
while($dt=mysqli_fetch_array($qr))
{
    $tbno = $dt['ex_bno1'];
    $tdt = $dt['tbdate'];
?>
                                            <tr>
<td><?php echo date("d/m/Y", strtotime($tdt)); ?></td>

<td><?php echo $dt['ex_bno1'];?></td>


<?php
$tq = "select sum(tamt)as tot from tbltaxdetails where ex_bno1='$tbno'";
$qr2=mysqli_query($conn,$tq);
// echo$tq;
while($dt2=mysqli_fetch_array($qr2))
{

$a1=$dt2['tot'];

// $exbno = $dt2['ex_bno1'];
$hi = "select sgst,cgst,igst,gstbno from tblgst where gstbno='$tbno' and sgst!=''";
// echo$hi;
$qrt2=mysqli_query($conn,$hi);

while($tempdt2=mysqli_fetch_array($qrt2))
{


if($tempdt2['igst']==''){
    $tigst = 0;
}
else if($tempdt2['igst']!=''){
    $tigst = $tempdt2['igst']; 
}


if($tempdt2['cgst']==''){
    $tcgst = 0;
}
else if($tempdt2['cgst']!=''){
    $tcgst = $tempdt2['cgst']; 
}


if($tempdt2['sgst']==''){
    $tsgst = 0;
}
else if($tempdt2['sgst']!=''){
    $tsgst = $tempdt2['sgst']; 
}



$a1g1 = $tsgst * $a1 * 0.01;
$a1g2 = $tcgst * $a1 * 0.01;
$a1g3 = $tigst * $a1 * 0.01;
}
$a1_tot = $a1+$a1g1+$a1g2+$a1g3;

?>
<td><?php echo $a1_tot;  ?></td>
<td><a href="taxable_print.php?bno=<?php echo$dt['tbno'];?>"><span style="font-size: 2em;" class="material-symbols-outlined">print </span></a></td>
<td><a href="taxable_duplicate.php?bno=<?php echo$dt['tbno'];  ?>" style="font-size: 2em;" class="material-symbols-outlined">file_copy </span></td> 
<td><a href="taxable_print_without.php?bno=<?php echo$dt['tbno']; } ?>"><span style="font-size: 2em;" class="material-symbols-outlined">print </span></a></td>    
<td><a href="delete_bos.php?id=<?php echo$dt['tbno'];?>"><span style="font-size: 2em;" class="material-symbols-outlined">delete </span></a></td>  

</tr>
<?php
}



?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    <script src="js/data-table/bootstrap-table.js"></script>
    <script src="js/data-table/tableExport.js"></script>
    <script src="js/data-table/data-table-active.js"></script>
    <script src="js/data-table/bootstrap-table-editable.js"></script>
    <script src="js/data-table/bootstrap-editable.js"></script>
    <script src="js/data-table/bootstrap-table-resizable.js"></script>
    <script src="js/data-table/colResizable-1.5.source.js"></script>
    <script src="js/data-table/bootstrap-table-export.js"></script>
    <!--  editable JS
        ============================================ -->
    <script src="js/editable/jquery.mockjax.js"></script>
    <script src="js/editable/mock-active.js"></script>
    <script src="js/editable/select2.js"></script>
    <script src="js/editable/moment.min.js"></script>
    <script src="js/editable/bootstrap-datetimepicker.js"></script>
    <script src="js/editable/bootstrap-editable.js"></script>
    <script src="js/editable/xediable-active.js"></script>
</body>
<?php
include("fotter.php");
?>
</html>