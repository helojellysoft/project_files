  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
        <style>
          *{
            font-size:12 ;
          }
          .pb{
            text-align-last: center;

          }
          .dtryt{
            float:right ;
          }
                    
.total{
  text-align: center;
  background-color: #7f7f7f;
}

//total{
  color: #000000;
  font-size: 18px;
  padding: 5px 0;
  display: inline-block;
  border-top: 1px solid #000000;
  border-bottom: 3px solid #000000;  
}
.footr{
  /*text-align-last: center;color: #040433;*/
  margin-bottom: 700px;

}
.notepad
{  text-align-last: center;color: #030f4d;


}
.note2{ 
 text-align-last: center;color:goldenrod;


}


        </style>


  </head>
  <body>
    <?php
    // include("nav.php");
    $server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
$quote_no=$_REQUEST['bno'];
    ?>
      <h2 class="notepad">DIAMOND CARGO MOVERS</h2> 
      <h5 class="note2">Shipping,Freight Forwarding,Clearing & Forwarding Agents</h5>
      <h5 class="note2">(Total Logestic Solution Provider)</h5>
<?php
$qr=mysqli_query($conn,"select * from tbltaxbill where tbno='$quote_no' and ex_status='0'");
while($dt=mysqli_fetch_array($qr))
{
    $tbno = $dt['tbno'];
?>    
      <h2 class="pb">GSTIN:33AGPR7201R1ZQ</h2>
    <h2 class="pb">Bill Of Supply<h2>
      <h4 class="dtryt">Date:<?php echo date("d/m/Y", strtotime($dt['tbdate'])); ?></h4>
      <h5>Bill No.<?php echo$dt['tbno']; ?></h5>

<?php
$n1 = $dt['tbto'];
$vqr=mysqli_query($conn,"select * from ship1_party where name='$n1'");
while($vdt=mysqli_fetch_array($vqr))
{

$d1 = $vdt['gst'];
$d2 = $vdt['district'];
}
?>

      <h5>To:<?php echo$dt['tbper']; ?>,<?php echo$d2; ?>.</h5>
      <h5>   GSTIN:<?php echo$d1; ?></h5>
      &nbsp;
      <h5>Shipped per:<?php echo$dt['tbto']; ?></h5>
      <h5>Particulars Of Cargo: <?php echo$dt['tbpart']; ?></h5>
      <h5>Under S.B/B.E.No.&Dt.<?php echo$dt['ex_bno1']; ?>/<?php echo date("d-m-Y", strtotime($dt['ex_dt1'])); ?></h5>
      <h5>Invoice No.&Dt.<?php echo$dt['ex_bno2']; ?>/<?php echo date("d-m-Y", strtotime($dt['ex_dt2'])); } ?></h5>
      <!-- <hr style="border-bottom:solid dark blue 1px;"> -->
    <table class="table table-borderless table-sm">
  <thead>
        
    <tr style="border-bottom:1px solid black; border-top: 1px solid black;">
      <th scope="col">Sno</th>
      <th scope="col">particulars</th>
      <th scope="col" style="text-align: right;">HSN Code</th>
      <th scope="col" style="text-align: right;">Amount(Rs.ps)</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
<?php
$c=0;
$s=0;
$qr2=mysqli_query($conn,"select * from tbltaxdetails where tbno='$quote_no' and tax_info='0'");
while($dt2=mysqli_fetch_array($qr2))
{
    $c=$c+1;
    // $tbno = $dt2['qino'];
     $s=$s+$dt2['tamt'];
$rowcount=mysqli_num_rows($qr2);   
// echo"hacked".$rowcount;  
?>
    <tr>
      <th scope="row"><?php echo$c; ?></th>
      <td><?php echo$dt2['tpart']; ?></td>
      <td style="text-align: right;"><?php echo$dt2['hsn']; ?></td>
      <td style="text-align: right;"><?php echo number_format((float)$dt2['tamt'],2,'.','') ; } ?></td>
    </tr>
  <?php 
  // $bill_amt  = $s+$cgstamt + $sgstamt + $igstamt;
  $nv = round($s); 
  $ls = $s-$nv;
  ?>
<tr>
  <td></td>
  <td></td>  
  <td style="text-align:right; padding-right: 200px;"></td>
  <td style="border-top: 1px dashed black;  border-bottom: 1px dashed black; text-align: right;"><?php echo number_format((float)$s,2,'.','') ; ?><br>(-)<?php echo number_format((float)$ls,2,'.',''); ?></td>
</tr>    




<tr>
  <td></td>
  <td></td>  
  <td style="text-align:right; padding-right: 200px;">Total</td>
  <td style="border-bottom: 1px dashed black; text-align: right;"><?php echo number_format((float)$nv,2,'.',''); ?></td>
</tr>

    </tbody>
</table>

  </tbody>
</table>
 <?php 
include"no2text.php";
$get_amount= AmountInWords($nv);
?>

   <h4 class="pb" style="margin-bottom: 10px;"> (Rupess <?php echo$get_amount; ?>only)<h4>
  
<table>
  
<?php 
for($i=1;$i<=15-$rowcount; $i++){

?>
    <tr>
      <th scope="row">&nbsp;</th>
      <td>&nbsp;</td>
      <td style="text-align: right;">&nbsp;</td>
      <td style="text-align: right;">&nbsp;</td>
    </tr>

<?php
}

?>
</table>
<label>Bank A/C Details:</label><label style="float: right;">for DIAMOND CARGO MOVERS</label><br>
<label>Name: DIAMOND CARGO MOVERS</label><br>
<label>Bank: CITY UNION BANK LTD</label><br>
<label>Branch: Tuticorin</label><label style="float: right;">
Proprietor/Authorised Signatory</label><br>
<label>Current A/C No: 085109000091123</label><br>
<label>IFSC:CIUB0000085</label><br><br>
<b>Declaration:</b><br>
<ol type="1">
  <li>I/We Declare that this invoice  shows actual price of the goods/or services described and that all particulars are true and correct.</li>
  <li>Disputes related in this invoice will be subject to the jurisdiction of the Tuticorin.</li>
</ol>



<center>    
          <hr class ="" style="border-bottom: 2px solid darkblue;">
           <h5 class="">4/6A1,New Salt Colony, Tiruchendur Road,Thoothukudi-628 003.</h5>
          <h5 class="">Ph:0461-2376629,4004639  Mobile:94434 04523 E-mail:diamondcargomovers@yahoo.co.in</h5>
</center>          


    
  </body>
</html>
