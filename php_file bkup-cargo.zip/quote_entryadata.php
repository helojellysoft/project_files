<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "insert";

$con1 = mysqli_connect("localhost", "root", "", "insert");
if($con1 == false){
	die("Error:Could'nt Connect".mysqli_connect_error());
}

$b1 = $_GET['jaino'];
$b2 = $_GET['ar1'];
$b3 = $_GET['ar2'];
for($i=0;$i<count($b2);$i=$i+1){
	//echo$b1[$i]."<br>";
	//echo$b2[$i];

	$sql1="insert into tblquote_details1(jaino, japarticular,jaamount)values('$b1','$b2[$i]','$b3[$i]')";
	echo$sql1;

	$res1=mysqli_query($con1,$sql1);
}

?>