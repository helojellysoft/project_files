<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert2";
$conn=new mysqli($server,$username,$password,$dbname);
$pid=$_POST['sno'];
$vdate=$_POST['date'];
$vsupplier=$_POST['supplier'];
$vcargo=$_POST['cargo'];
$vpackage=$_POST['package'];
$vnetweight=$_POST['netweight'];
$vgsweight=$_POST['gsweight'];
$vsbno=$_POST['sbno'];
$vbcno=$_POST['bcno'];
$vvessel=$_POST['vessel'];
$vdischarge=$_POST['discharge'];
$qr="update ship2 set date='$vdate',supplier='$vsupplier',cargo='$vcargo' ,package='$vpackage', netweight='$vnetweight',gsweight='$vgsweight',sbno='$vsbno',bcno='$vbcno',vessel='$vvessel',discharge='$vdischarge' where sno='$pid'";
if ($conn->query($qr)==True) {
// echo$qr;
header("location:data-table.php");
  }else

 {
  echo "Error:" .$qr. "<br>".$conn->error;
  }
?>