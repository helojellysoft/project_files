<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <style>
    	table{
    		font-size: 12px;
    		border-style: none;
    	}

    	.tdfour{
    		/*visibility: hidden;*/
    		text-decoration-line: overline;
    	}
    	.tdthree{
    		text-decoration-line: underline;
    		text-transform: capitalize;
    	}
    	.five{
    		width: 50%;
    	}
    	.heading{
    		text-align: center;
    	}
    	.tdtwo{
    		text-decoration-line: underline;
    	}
    	td,tr,th{
    		border-style: none;
    	}

    </style>
    <?php
    // include("nav.php");
    $server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
    ?>

    <body>
	<h1 class="heading"  style="visibility: hidden;">CERTIFICATE OF ORIGIN</h1>
	<table class="table table-bordered table-sm">
<?php
$coid = $_GET['coidno'];
$i="select * from tblcoo where coidno='$coid' ";
$ir=mysqli_query($conn,$i);
while($it=mysqli_fetch_array($ir))
{
    $va = $it['coexport'];
    $va1 = $it['coconsigne'];
$i2="select * from ship1 where name='$va' ";
$ir2=mysqli_query($conn,$i2);
while($it2=mysqli_fetch_array($ir2))
{
	$a1=$it2['address'];
	$a2 = $it2['district'];
	$a3 = $it2['state'];
	$a4 = $it2['country'];
}

$i3="select * from ship where name='$va1' ";
$ir3=mysqli_query($conn,$i3);
while($it3=mysqli_fetch_array($ir3))
{
	$a11=$it3['address'];
	$a21 = $it3['district'];
	$a31 = $it3['state'];
	$a41 = $it3['country'];
}

?>

		<tr>
			<td colspan="2" class="one"><label  style="visibility: hidden;">exporter</label><br><b> <?php echo$va;  ?></b><br><?php echo$a1;  ?>,<br><?php echo$a2;  ?><br><?php echo$a3;  ?>,<?php echo$a4;  ?>.</td>
			<td rowspan="5" colspan="3" class="two"><b  style="visibility: hidden;">tuticorin Exporters & Importers chamber</b><br> <label  style="visibility: hidden;"> estd:1944</label><br> <label  style="visibility: hidden;"> (0.no.52A)143,south india raja street,tuticorin-628001.</label><br> <label  style="visibility: hidden;"> SOUTH INDIA</label><br><br><center><b>Notify:</b><br>JATOI GENERAL TRADING LLC.<br>P.O.BOX NO.242653,<br>DUBAI,UAE.<br><b>2nd Notify<br>Ghulam mohd.haji trading CO.L.L.C.<br>onion storage no.19 AL-AwirFruit& veg<br>Market Dubai.UAE.</b></center></td> 
		</tr>
		<tr>
			<td colspan="2" class="three"><label  style="visibility: hidden;">consignee</label><br><b><?php echo$va1; } ?></b><br><?php echo$a11;  ?>,<br><?php echo$a21;  ?>,<?php echo$a31;  ?><br><?php echo$a41;  ?>.</td>
		</tr>
		<tr class="Rone">
			<td><label  style="visibility: hidden;">pre-carrage by</label></td>
			<td> <label  style="visibility: hidden;"> please of receipt by pre-carrier</label></td>
		</tr>
		<tr class="Rtwo">
			<td><label  style="visibility: hidden;"> vessal/fight No</label><br>MV.KAPITAN MASLOV V.168S</td>
			<td><label  style="visibility: hidden;"> port of loading </label><br>TUTICORIN</td>
		</tr>
		<tr class="Rthree">
			<td><label  style="visibility: hidden;"> port of disherge </label><br>COLOMBO</td>
			<td><label  style="visibility: hidden;"> Final Destination </label><br>SRI LANKA</td>
		</tr>
		<tr class="Rfour" style="border-collapse: collapse;">
			<td width="20px"><label style="visibility: hidden;"> marks&nos/container No.</label></td>
			<td colspan="2"><label style="visibility: hidden;">No. & kinds of pkgs &nbsp;&nbsp;&nbsp;descrption of goods</label> </td>
			<td><label style="visibility: hidden;">Quality</label> </td>
			<td style="width: 15%;"><label style="visibility: hidden;"> value</label></td>
		</tr>
<?php
$ni="select * from tblcoo_details where coidno='$coid' ";
$nir=mysqli_query($conn,$ni);
while($nit=mysqli_fetch_array($nir))
{
?>

		<tr>
			<td><?php echo$nit['comarks']; ?></td>
			<td colspan="1" class="" style="width:200px;"><?php echo$nit['codesc']; ?></td>


			<td align="left" ><?php echo$nit['coqty'];  ?></td>
			<td></td>

			<td></td>
		</tr>
<?php 
}

?>


<!-- 
		<tr><td>1</td><td>1</td><td>1</td><td>1</td><td>1</td></tr>
		<tr><td>1</td><td>1</td><td>1</td><td>1</td><td>1</td></tr>
		<tr><td>1</td><td>1</td><td>1</td><td>1</td><td>1</td></tr> -->		

		<tr>
			<td colspan="2" class="five"><span class="tdtwo"><center style="visibility: hidden;">CERTIFICATION</center></span><br><label style="visibility: hidden;"> it is hereby certified that this declaration was made before me and that to the best of my knowledge and belife the above mentioned goods are indian origin</label></td>
			<td colspan="3" class="six"><center><span class="tdthree"> <label style="visibility: hidden;"> declaration by exporter</label></span><br><label style="visibility: hidden;">we hereby declare that the above mentioned goods were produced/manufactured in India.</label><br><br><label style="visibility: hidden;">FOR RAISONI EXPORTS</label><br><br><label style="visibility: hidden;">Authorised signatory</label><br><br><span class="tdfour"> <label style="visibility: hidden;"> Name of the Authorised signatory</label><br><br><label style="visibility: hidden;"> signatory and date</label></span></center></td>
		</tr>


	</table>
</body>
</html>