<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <style>
    .hone{
      text-decoration: underline;
    }
    .one{
      width:10em;
    }
    *{
      font-size: 13px;
    }
    .ttwo{
      width:12%;
    }
    .tthree{
      margin-right:10px;
    }
  
    </style>
  </head>
  <body>
    <?php
    // include("nav.php");
    $server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
$quote_no=$_REQUEST['qno'];
$qr22=mysqli_query($conn,"select * from tblquote where qino='$quote_no'");
while($dt22=mysqli_fetch_array($qr22))
{
    $tbno = $dt22['qino'];
?>
    <center><h3 class="hone"><?php echo $dt22['e1']; } ?></h3><br></center>
    <table class="table table-borderless table-sm">
<?php
$qr=mysqli_query($conn,"select * from tblquote_details1 where jaino='$quote_no'");
$s1=0;
$c1=0;
while($dt=mysqli_fetch_array($qr))
{
    $c1=$c1+1;
    $tbno = $dt['jaino'];
    $s1 = $s1+$dt['jaamount'];
?>
      <tr>
        <td class="one"><?php echo $c1; ?> </td>
        <td class="two"><?php echo $dt['japarticular']; ?></td>
        <td class="three" style="text-align:right;"><?php echo $dt['jaamount']; ?></td>

      </tr>
<?php
}
?>
<tr>
  <td></td>
  <td style="text-align:right; padding-right: 200px;">Total</td>
  <td style="border-top: 1px dashed black; border-bottom: 2px dashed black; text-align: right;"><?php echo $s1; ?></td>
</tr>
    </table>
    <table class="table table-borderless table-sm">
<?php
$qr2=mysqli_query($conn,"select * from tblquote_details2 where jasino='$quote_no'");
$s=0;
$c=0;
while($dt2=mysqli_fetch_array($qr2))
{
    $s = $s+$dt2['jasamount'];
    $c=$c+1;
?> 
    <tr>
      <td class="one"><?php echo $c; ?></td>
      <td class="two"><?php echo $dt2['jasparticular']; ?></td>
      <td class="three" style="text-align: right;"><?php echo $dt2['jasamount']; ?></td>
    </tr>
 <?php
}
?>
<tr>
  <td></td>
  <td style="text-align:right; padding-right: 200px;">Total</td>
  <td style="border-top: 1px dashed black; border-bottom: 2px dashed black; text-align: right;"><?php echo $s; ?></td>
</tr>
  </table>
  <center><h3>Grand total Approx.ind.Rs.<?php echo $s1+$s; ?>.00(including GST Rs.3870.00)</h3>
<?php
$qr222=mysqli_query($conn,"select * from tblquote where qino='$quote_no'");
while($dt222=mysqli_fetch_array($qr222))
{
  ?>
  <span><?php echo $dt222['e2']; ?> </span></center>
  <span><?php echo $dt222['e3']; } ?></span>
  <ol style="font-weight: bold;">
  <li>Trainer Halt Fire-Rs.1500/-per Day+Driver Batta Rs.100/-</li>
  <li>Custome Ot Min Rs.300/- </li>
  <li>Any charges Related in Shipment Actual</li>
  <li>Any Scaning of custome,will  be RS.1000/-per Fcl</li>
  <li>Any Assessment will be Rs.500/-per bill</li>
  <li>EXTRA EXPENSES AT CTS FOR 100% EXAMINATION WILL BE RS.2000.00 PER FCL</h4></li></ol>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
  </body>
</html>