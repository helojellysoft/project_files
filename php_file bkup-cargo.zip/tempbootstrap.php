<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<script type="text/javascript" src="dist/jquery.tabledit.js"></script>
    <link rel="stylesheet" href="css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="css/data-table/bootstrap-editable.css">
</head>
<body>
	<table id="data_table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true"
                                        data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                        <thead>
                                            <tr>
                                                <th data-field="name" data-editable="true">Name</th>
                                                <th data-field="email" data-editable="true">Mobile No</th>
                                                <th data-field="phone" data-editable="true">Email</th>
                                                <th data-field="task" data-editable="true">Address</th>
                                                <th data-field="date" data-editable="true">District</th>
                                                <th data-field="a1" data-editable="true">State</th>
                                                <th data-field="a2" data-editable="true">Country</th>
                                                <th data-field="a3" data-editable="true">GST No</th>
                                                <th data-field="a4" data-editable="true">Remark</th>
                                                <th data-field="delete">Delete</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        	<td>abc</td>
                                        	<td>abc</td>
                                        	<td>abc</td>
                                        	<td>abc</td>
                                        	<td>abc</td>
                                        	<td>abc</td>
                                        	<td>abc</td>
                                        	<td>abc</td>
                                        	<td>abc</td>
                                        	<td>abc</td>
                                        </tbody>	
	</table>
<script type="text/javascript" src="custom_table_edit.js"></script>
</body>
</html>