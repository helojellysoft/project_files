<!DOCTYPE html>
<html>
<head>
	<title>INVOICE</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

<style type="text/css">
	*{
		font-size: 11px;
		font-weight:
	}
	.bold{
		font-weight: bold;
	}
	#cen{
		text-align: center;
	}
	.{
		border:hidden
		/*class="border border-white"*/
	}
	th,td,tr{
		border: 1px solid black;
	}
</style>

</head>
<body>

<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);


$pid=$_REQUEST['id'];
$qr=mysqli_query($conn,"select * from tblbill where bino='$pid'");
while($dt=mysqli_fetch_array($qr))
{
$n1 = 	$dt['bexporter'];
$n2 = 	$dt['bconsignee'];
$title = $dt['Inv_title'];
$dte = $dt['bdate'];
$prekg = $dt['borigin'];
$precpt = $dt['bdesign'];
$vsno = $dt['bflno'];
$p_term = $dt['pay_term'];
$Inv_buyer = $dt['Inv_buyer'];
$Inv_hsn  = $dt['Inv_hsn'];

?>	
	<table class="table table-bordered table-sm">
			<tr>
				<th colspan="9"><center><?php echo $title;  } ?></center></th>
			</tr>
<?php
$qr2=mysqli_query($conn,"select * from ship1 where name='$n1'");
while($dt2=mysqli_fetch_array($qr2))
{

	?>			
			<tr>
				<td colspan="4" rowspan="3">EXPORTER<br><b><?php echo$dt2['name']; ?> <br><?php echo$dt2['mobile']; ?>,<br><?php echo$dt2['address']; ?>,<br><?php echo$dt2['state']; ?>,<?php echo$dt2['country'];  } ?>.</b></td>
				<td colspan="3"><b>INVOICE NO <br><?php echo$pid; ?></b></td>
				<td colspan="2"><b>DATE <br><?php echo$dte; ?></b></td>
			</tr>

			<tr>
				<td colspan="5"><center>BUYERS'S ORDER NO & DATE</center></td>
			</tr>
			<tr>
				<td colspan="5">OTHER REFERENCE(S) FROM SDF</td>
			</tr>

<?php
$qr3=mysqli_query($conn,"select * from ship where name='$n2'");
while($dt3=mysqli_fetch_array($qr3))
{
?>
			<tr>
				<td colspan="4" rowspan="3">CONSIGNEE<br><b><?php echo$dt3['name'];  ?>.,</b><br><?php echo$dt3['address'];  ?>,<br><?php echo$dt3['district'];  ?>,<br><?php echo$dt3['state'];  ?>,<br><b><?php echo$dt3['country'];  } ?></b></td>
				<td colspan="5">BUYER (IF OTHER THAN CONSIGNEE)<br><b><?php echo$Inv_buyer; ?></b></td>
			</tr>
			<tr>
				<td colspan="3"><center>COUNTRY OF ORIGIN OF GOODS</center></td>
				<td colspan="2"><center>COUNTRY OF FINAL DESTINATION</center></td>
			</tr>
			<tr>
				<td colspan="3"><center><b>INDIA</b></center></td>
				<td colspan="2"><center><b>SRILANKA</b></center></td>
			</tr>
			<tr>
				<td colspan="2">PRE-CARRIAGE BY:<?php echo$prekg; ?></td>
				<td colspan="2">PLACE OF RECIPT BY<br><?php echo$precpt; ?></td>
				<td colspan="5" rowspan="3">PAYMENT TERM's<br><b><?php echo$p_term; ?><br><label style="visibility:hidden;">100% ADVANCE TT</label></b></td>
			</tr>
			<tr>
				<td colspan="2">VESSEL/FRIEGHT NO<br><?php echo$vsno; ?></td>
				<td colspan="2">PORT OF LOADING<br><b>TUTICORIN, INDIA</b></td>
			</tr>
			<tr>
				<td colspan="2">PORT OF DISCHARGE<br><b>COLOMBO, SRILANKA</b></td>
				<td colspan="2">PLACE OF DELIVERY<br><b>COLOMBO, SRILANKA</b></td>
			</tr>
			<tr id="cen">
				<th>MARKS & NOS</th>
				<th>NO & KIND OF PACKAGES</th>
				<th colspan="4"><center>DESCRIPTION OF THE GOODS</center></th>
				<th>QUANTITY<br>Metric Tons</th>
				<th>RATE<br>USD/MT</th>
				<th>TOTAL<br>USD</th>
			</tr>
<?php
$qr4=mysqli_query($conn,"select * from tbldetails where dino='$pid'");
while($dt4=mysqli_fetch_array($qr4))
{
?>			
			<tr id="cen" class="bold">
				<td><?php echo$dt4['dmno']; ?></td>
				<td><?php echo$dt4['dnpack']; ?></td>
				<td colspan="4"><?php echo$dt4['dinfo']; ?></td>
				<td><center><?php echo$dt4['dqty']; ?></center></td>
				<td><center><?php echo$dt4['drate']; ?></center></td>
				<td><center><?php echo$dt4['dqty']*$dt4['drate']; ?></center></td>
			</tr>
<?php
} 
?>
<!-- 			<tr id="cen" class="bold">
				<td>LIRA 1 TO 560</td>
				<td>560 BAGS</td>
				<td colspan="4">RED CHILLIES MEDIUM 334</td>
				<td><center>14.000</center></td>
				<td><center>2100.00</center></td>
				<td><center>29400.00</center></td>
			</tr>
			<tr id="cen" class="bold">
				<td>LIRA 1 TO 560</td>
				<td>560 BAGS</td>
				<td colspan="4">RED CHILLIES MEDIUM 334</td>
				<td><center>14.000</center></td>
				<td><center>2100.00</center></td>
				<td><center>29400.00</center></td>
			</tr> -->						
			<tr>
				<td></td>
				<td></td>
				<td colspan="4">HS CODE : <?php echo$Inv_hsn; ?></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
<?php
$qr5=mysqli_query($conn,"select sum(dqty*drate)as tot from tbldetails where dino='$pid'");
while($dt5=mysqli_fetch_array($qr5))
{
	$cif_value=$dt5['tot'];
?>				
			<tr>
				<td></td>
				<td></td>
				<td>CIF VALUE :</td>
				<td colspan="3">USD.<?php echo$cif_value; } ?>.00</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
<?php
$qr6=mysqli_query($conn,"select * from tblbill where bino='$pid'");
while($dt6=mysqli_fetch_array($qr6))
{
	$tot_net = $dt6['bnet_wt']* $dt6['btotal_bag'];
	$tot_gross = $dt6['bgross_wt']* $dt6['btotal_bag'];
	$contno = $dt6['con_no'];
	$arn = $dt6['arn'];
	$iecno = $dt6['iec_no'];
	$pan = $dt6['pan_no'];
	$gst = $dt6['gst_no'];
?>				
			<tr>
				<td></td>
				<td></td>
				<td>FREIGHT VALUE :</td>
				<td colspan="3">USD.<?php echo$dt6['bfrate']; ?>.00</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td>INSURANCE :</td>
				<td colspan="3">USD.<?php echo$dt6['binsure']; ?></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td>FOB VALUE :</td>
				<td colspan="3">USD.<?php echo$dt6['bfob'];  ?></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td>TOTAL NO.OF.BAGS</td>
				<td>SL.NO. OF BAGS</td>
				<td>EACH BAG NET WT.(KGS)</td>
				<td>EACH BAG GROSS WT.(KGS)</td>	
				<td>TOTAL BAG GROSS WEIGHT (MTS)</td>
				<td>TOTAL BAG NET WEIGHT (MTS)</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td><?php echo$dt6['btotal_bag']; ?></td>
				<td><?php echo$dt6['bslno_bag']; ?></td>
				<td><?php echo$dt6['bnet_wt']; ?></td>
				<td><?php echo$dt6['bgross_wt']; ?></td>
				<td><?php echo$tot_gross; ?></td>
				<td><?php echo$tot_net;  }?></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td colspan="3" style="visibility: hidden;">FIVE HUNDRED AND SIXTY BAGS ONLY</td>
				<td colspan="3" style="visibility: hidden;">PACKED IN JUTE BAGS ONLY</td>
				<td></td>
				<td></td> 
				<td></td>
			</tr>
<?php
$bankqr=mysqli_query($conn,"select * from ship1 where name='$n1'");
while($bankdt=mysqli_fetch_array($bankqr))
{
$b1 = $bankdt['ex_acname'];
$b2 = $bankdt['ex_acno'];
$b3 = $bankdt['ex_ifsc'];
$b4 = $bankdt['ex_swiftcode'];
$b5 = $bankdt['ex_adcode'];
$b6 = $bankdt['ex_bankname'];
$b7 = $bankdt['ex_bankaddress'];
$b8 = $bankdt['ex_bankdist'];
$b9 = $bankdt['ex_bankstate'];
$b10 = $bankdt['ex_bankcountry'];
}
?>


			<tr>
				<td class="bold" rowspan="" colspan="3">BANKER DETAILS:<br><?php echo$b6; ?>,<br><?php echo$b7; ?>,<br><?php echo$b8; ?>.<br>CERTIFIED THAT GOODS ARE OF <?php echo$b10; ?> ORIGIN.</td>
				<td rowspan="" colspan="3"><b>NAME : <?php echo$b1; ?><br>CC A/C NO:<?php echo$b2; ?><br>IFSC CODE:&nbsp;&nbsp;&nbsp;<?php echo$b3; ?></b><br>SWIFT CODE:&nbsp;&nbsp;<?php echo$b4; ?><br>AD CODE: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo$b5; ?></td>
				<td></td>
				<td></td> 
				<td></td>
			</tr>
			<tr>
				<td colspan="6">AMOUNT IN WORDS :</td>
				<td>14.000</td>
				<td></td> 
				<td><?php echo$cif_value; ?></td>
			</tr>
<?php 
include"no2text.php";
$get_amount= AmountInWords($cif_value);
?>			
			<tr>
				<td colspan="9"><center>(USD <?php echo$get_amount; ?> ONLY)</center></td>
			</tr>
			<tr>
				<td class="bold" colspan="5">CONTAINER NO : <?php echo$contno; ?>:</td>
				<td class="bold" rowspan="5" colspan="4">SIGNATURE<br><br><br><br><br><br><br>AUTHORISED SIGNATORY</td>
			</tr>
			<tr>	
				<td colspan="5">ARN : <?php echo$arn; ?> &nbsp; </td>
			</tr>
			<tr>
				<td colspan="2">IEC NO : <?php echo$iecno; ?></td>
				<td colspan="3">PAN NO : <?php echo$pan; ?></td>

			</tr>
			<tr>
				<td colspan="5">GST NO : <?php echo$gst; ?></td>
			</tr>
			<tr>
				<td colspan="5"><b>DECLARATION :</b><br>WE DECLARE THAT THIS INVOICE SHOWS THE ACTUAL PRICE OF THE GOODS DESCRIBED & THAT ALL PARTICULARS ARE TRUE AND CORRECT.</td>
			</tr>
	</table>					

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
</body>
</html>