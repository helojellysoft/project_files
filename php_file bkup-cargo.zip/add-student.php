<!doctype html>
<html class="no-js" lang="en">

<body>
<?php
include("nav.php");
?>
</body>
<?php
include("fotter.php");
?>
</html>