<html>
<style>
	*{
		margin: 0;
		/*height: 0;*/
		/*width: 0;*/
	}
table, td, th {  

  text-align: left;
}
*{
  font-family: Book Antiqua;
}
table {
  border-collapse: collapse;
  width: 100%;
}
tr{
  line-height: 11px;
}

.sno{

width: 3% !important; 

}
.parti{

width: 80% !important; 

}
.hsn{
	width: 10%;
}
.amount{
	width: 10% !important;
}

th, td {
  padding: 5px;

}
.cargo{
	font-size: 1.5em;
	font-weight: bold;
}

</style>
<body>
    <?php
    // include("nav.php");
    $server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
$quote_no=$_REQUEST['bno'];
    ?>

    <?php
$qr=mysqli_query($conn,"select * from tbltaxbill where tbno='$quote_no' and ex_status='1'");
while($dt=mysqli_fetch_array($qr))
{
    $tbno = $dt['tbno'];
?> 	
	<!-- <center>
<span class="cargo">DIAMOND CARGO MOVERS</span><br><label>Shipping,Freight Forwarding,Clearing & Forwarding Agents</label><br><label>(Total Logestic Solution Provider)</label><br>
	GSTIN:33AGPPR7201R1ZQ</center> -->
<table>
<tr style=" border: 1px solid black;" >
<td colspan="11"  style="text-align: center; padding: 3px;">TAX-INVOICE</td>

<?php
$n1="";
$d1="";
$d2="";
$n1 = $dt['tbto'];
$vqr=mysqli_query($conn,"select * from ship1_party where name='$n1'");
while($vdt=mysqli_fetch_array($vqr))
{
$d1 = $vdt['gst'];
$d2 = $vdt['district'];
}
?>

</tr> 
<tr style=" border: 1px solid black; " >
<td colspan="11" >Bill No: <?php echo$dt['tbno']; ?> <span style="float: right; padding:0px;"> Date-<?php echo date("d/m/Y", strtotime($dt['tbdate']));  ?></td>
</tr> 
<tr style=" line-height: 16px; border: 1px solid black;" >
<td colspan="11">To: <?php echo$dt['tbto']; ?>,<?php echo$d2; ?>.<br>GSTIN:<?php echo$d1;  ?></td></tr>
</tr> 	
<tr style=" line-height: 16px; border: 1px solid black;" >
<td colspan="11">Shipped per:<?php echo$dt['tbper']; ?><br>
Particulars Of Cargo: <?php echo$dt['tbpart']; ?><br>
Under S.B/B.E.No.&Dt. <?php echo$dt['ex_bno1']; ?>/<?php echo date("d-m-Y", strtotime($dt['ex_dt1'])); ?><br>
Invoice No.&Dt.<?php echo$dt['ex_bno2']; ?>/<?php echo date("d-m-Y", strtotime($dt['ex_dt2'])); } ?></td></tr>
<tr style="line-height: 14px;">
	<th rowspan="2"  class="sno" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;">Sl. No.</th>
      <th rowspan="2" class="parti" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >Particulars</th>
      <th  rowspan="2" class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >HSN</th>
      <th   rowspan="2" class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >Amount</th>
      <th  colspan="2" class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >CGST</th>
      <!-- <th class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >Amt</th> -->
      <!-- <th class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >%</th> -->
      <th    colspan="2" class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >SGST</th>      
      <!-- <th class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >%</th> -->
      <th    colspan="2" class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >IGST</th>
      <th  rowspan="2" class="amount" style="border-left:1px solid black;  border-bottom: 1px solid black; border-right:1px solid  black;" >Amount (Rs.ps)</th>
    </tr>
  <tr>
      <th class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >%</th>
      <th class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >Amt</th>
      <th class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >%</th>
      <th class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >Amt</th>      
      <th class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >%</th>
      <th class ="hsn" style="border-left:1px solid black; border-bottom: 1px solid black; text-align: center;" >Amt</th>
  </tr>
<?php
$c=0;
$s=0;
$n1_Amount_final=0;
$tbno="";
$qr2=mysqli_query($conn,"select * from tbltaxdetails where tbno='$quote_no' and tax_info='1'");
while($dt2=mysqli_fetch_array($qr2))
{
  $c=$c+1;  $n1_Amount=0;

    $tbno = $dt2['ex_bno1'];
    $s=$s+$dt2['tamt'];

$rowcount=mysqli_num_rows($qr2);

$colAmount = $s;
// echo$rowcount."hacked";

?>


<tr style="font-size: 0.93em;" >
	<td style="border-left:1px solid black; text-align:center;" ><?php echo$c; ?></td>
	<td style="border-left:1px solid black;" ><?php echo$dt2['tpart']; ?></td>
	<td style="border-left:1px solid black;" ><?php echo$dt2['hsn']; ?></td>
	<td style="border-left:1px solid black;text-align: right;" ><?php echo$dt2['tamt']; ?></td>
  <?php 
  $cgst_amt=0;
  $sgst_amt=0;
  $igst_amt=0;
  if($dt2['new_cgst']!=''){ 
    $cgst_amt=$dt2['tamt']*$dt2['new_cgst']/100;
    ?>
	<td style="border-left:1px solid black;" ><?php echo$dt2['new_cgst'];  ?></td>
  <td style="border-left:1px solid black;text-align: right;" ><?php  echo number_format((float)$cgst_amt, 2, '.', ''); ?></td>
  <?php 
  } 
  else {
    ?>
  <td style="border-left:1px solid black;" ></td>
  <td style="border-left:1px solid black;"></td>
    <?php
  }  if($dt2['new_sgst']!=''){ 
    $sgst_amt=$dt2['tamt']*$dt2['new_sgst']/100;
    ?>
	<td style="border-left:1px solid black;" ><?php echo$dt2['new_sgst'];  ?></td>
  <td style="border-left:1px solid black;text-align: right;" ><?php  echo number_format((float)$sgst_amt, 2, '.', '');  ?></td>
  <?php 
  }
  else {
    ?>
  <td style="border-left:1px solid black;" ></td>
  <td style="border-left:1px solid black;"></td>
    <?php
  }
  $tot_igst_new=0;
  if($dt2['new_igst']!=''){ 
    $igst_amt=$dt2['tamt']*$dt2['new_igst']/100;
    $tot_igst_new = $tot_igst_new + $igst_amt;
    ?>
	<td style="border-left:1px solid black;" ><?php echo$dt2['new_igst'];  ?></td>
  <td style="border-left:1px solid black;text-align: right;" ><?php  echo number_format((float)$igst_amt, 2, '.', '');  ?></td>
  <?php 
  }
  else {
    ?>
  <td style="border-left:1px solid black;" ></td>
  <td style="border-left:1px solid black;"></td>
    <?php
  }
  $net_amt = $dt2['tamt']+$cgst_amt + $sgst_amt +$igst_amt; 
  $n1_Amount = $n1_Amount+$net_amt;
  $n1_Amount_final = $n1_Amount_final+$net_amt;

  // $nv =  round($n1_Amount,0,PHP_ROUND_HALF_DOWN);  
  // $ls = $nv-$s;

?>
	<td style="border-left:1px solid black;  text-align: right; border-right:1px solid black;" ><?php  echo number_format((float)$n1_Amount, 2, '.', '');  } ?></td>
</tr>



<?php
for($i=1;$i<=19-$rowcount;$i=$i+1)
{
	?>
	    <tr  style="font-size: 0.93em;">
      <th style="border-left:1px solid black;" scope="row">&nbsp;</th>
      <td style="border-left:1px solid black;">&nbsp;</td>
      <td style="border-left:1px solid black;">&nbsp;</td>
      <td style="border-left:1px solid black;">&nbsp;</td>          
      <td style="border-left:1px solid black;">&nbsp;</td>            
      <td style="border-left:1px solid black;">&nbsp;</td>          
      <td style="border-left:1px solid black;">&nbsp;</td>          
      <td style="border-left:1px solid black;">&nbsp;</td>          
      <td style="border-left:1px solid black;">&nbsp;</td>          
      <td style="border-left:1px solid black;">&nbsp;</td>
      <td style="border-left:1px solid black; border-right:1px solid  black;">&nbsp;</td>
    </tr>
	<?php } 
?>

<?php



$nv =  round($n1_Amount_final,0,PHP_ROUND_HALF_DOWN);  
$ls = $nv-$n1_Amount_final;



$qr0=mysqli_query($conn,"select * from tbltaxdetails where ex_bno1='$tbno' and tax_info='1'");
// echo"select * from tblgst where gstbno='$tbno'";
$tot_gst1 =0;
while($dt0=mysqli_fetch_array($qr0)){
    if($dt0['new_sgst']!=''){
        $gst1 = $dt0['new_sgst'] * $dt0['tamt'] * 0.01; }
    elseif($dt0['new_sgst']==''){
    $gst1=0;    
    }
    $tot_gst1 = $tot_gst1+$gst1;        
    }
    
    $tot_gst2 = 0; 
    $qr00=mysqli_query($conn,"select * from tbltaxdetails where ex_bno1='$tbno' and tax_info='1'");
    // echo"select * from tblgst where gstbno='$tbno'";
    while($dt00=mysqli_fetch_array($qr00)){
        if($dt00['new_cgst']!=''){
        $gst2 = $dt00['new_cgst'] * $dt00['tamt'] * 0.01; }
        elseif($dt00['new_cgst']==''){
            $gst2=0;    
            }            
            $tot_gst2 = $tot_gst2+$gst2;            
    }
    $tot_gst3 = 0;
    $qr000=mysqli_query($conn,"select * from tbltaxdetails where ex_bno1='$tbno' and tax_info='1'");
    // echo"select * from tbltaxdetails where ex_bno1='$tbno' and tax_info='1'";
    while($dt000=mysqli_fetch_array($qr000)){
        if($dt000['new_igst']!=''){
        $gst3 = $dt000['new_igst'] * $dt000['tamt'] * 0.01; }
        elseif($dt000['new_igst']==''){
            $gst3=0;    
            }        
            $tot_gst3 = $tot_gst3+$gst3;            
            
    }




  ?> 

<tr>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black; border-top:1px dashed black; border-bottom:1px dashed black;"><?php echo$colAmount; ?></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black; border-top:1px dashed black; border-bottom:1px dashed black;"><?php echo$tot_gst1; ?></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black; border-top:1px dashed black; border-bottom:1px dashed black;"><?php echo$tot_gst2; ?></td>
  <td style="border-left:1px solid black;"></td>  
  <td style="border-left:1px solid black; border-top: 1px dashed black;  text-align: right;"><?php echo$tot_gst3; ?></td>
  <td style="border-left:1px solid black;  line-height: 13px; border-right:1px solid black; border-top: 1px dashed black;  text-align: right;"><?php echo number_format((float)$n1_Amount_final,2,'.',''); ?></td>
</tr>




  <tr>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>  
  <td style="border-left:1px solid black; border-top: 1px dashed black;  text-align: right;">R/Off</td>
  <td style="border-left:1px solid black;  line-height: 13px; border-right:1px solid black;  border-bottom: 1px dashed black; text-align: right;"><?php echo number_format((float)$ls,2,'.',''); ?></td>
</tr>


<?php 
  // $bill_amt  = $s+$cgstamt + $sgstamt + $igstamt;
  $nv =  round($n1_Amount_final,0,PHP_ROUND_HALF_DOWN);  
  $ls = $nv-$n1_Amount_final;
  ?>

<tr style="font-size: 0.93em;">
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>
  <td style="border-left:1px solid black;"></td>  
  <td style="border-left:1px solid black; text-align: right;">Total</td>
  <td style=" border-left:1px solid black; border-right:1px solid black; border-bottom: 1px dashed black; text-align: right;"><?php echo number_format((float)$nv,2,'.',''); ?></td>
</tr>










<?php 
include"no2text.php";
$get_amount= AmountInWords($nv);
?>







<table>
<tr style=" border: 1px solid black;" style="font-size: 0.93em;" >
  <td colspan="11" style="font-size: 0.93em;">Amount in words: Rupees <?php echo$get_amount; ?> Only <span style="float:right;">E.&O.E</span></td></tr>
</table>


<!-- 
table {table-layout:fixed}
td { white-space:nowrap}
 -->
 <table  style="table-layout:fixed;"> 
<tr style="  line-height: 15px;  border: 1px solid black;" >
  <td colspan="" style="width: 65% !important;"><label>Bank A/C Details:</label><br>
<label style="font-size: 0.93em;">Name: DIAMOND CARGO MOVERS</label><br>
<label  style="font-size: 0.93em;">Bank: CITY UNION BANK LTD</label><br>
<label style="font-size: 0.93em;">Branch: Tuticorin</label>
<br>
<label style="font-size: 0.93em;">Current A/C No: 085109000091123</label><br>
<label style="font-size: 0.93em;">IFSC:CIUB0000085</label>
  </td>
  <td colspan="" style="white-space: nowrap; border-left: 1px solid black;  border-right: 1px solid black; text-align: left;" >for DIAMOND CARGO MOVERS<br><br><br><br>Proprietor/Authorised Signatory</label></td>
</tr>
</table><table>
<tr style="  line-height: 16px; border-bottom: 1px solid black; border-left: 1px solid black; border-right: 1px solid black;">
  <td colspan="4"><b>Declaration:</b><br>
  <ol type="1" style="list-style-position: outside;"><li>I/We Declare that this invoice  shows actual price of the goods/or services described and that all particulars are true and correct.</li>
<li>Disputes related in this invoice will be subject to the jurisdiction of the Tuticorin.</li></ol>
</td>
</tr>
</table>
<!-- <center>    
          <hr class ="" style="border-bottom: 2px solid darkblue;">
          <h5 class="">4/6A1,New Salt Colony, Tiruchendur Road,Thoothukudi-628 003.</h5>
          <h5 class="">Ph:0461-2376629,4004639  Mobile:94434 04523 E-mail:diamondcargomovers@yahoo.co.in</h5>
</center>           -->

</body>
</html>