<!DOCTYPE html>
<html>
<head>
	<title>INVOICE</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

<style type="text/css">
	*{
		font-size: 11px;
		font-weight:
	}
	.bold{
		font-weight: bold;
	}
	#cen{
		text-align: center;
	}
	.{
		border:hidden
		/*class="border border-white"*/
	}
	th,td,tr{
		border: 1px solid black;
	}
</style>

</head>


<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);


$pid="spic"; //$_REQUEST['id'];
$qr=mysqli_query($conn,"select * from tblbill where bino='$pid'");
while($dt=mysqli_fetch_array($qr))
{
$n1 = 	$dt['bexporter'];
$n2 = 	$dt['bconsignee'];
$title = $dt['Inv_title'];
$dte = $dt['bdate'];
$prekg = $dt['borigin'];
$precpt = $dt['bdesign'];
$vsno = $dt['bvessno'];
$p_term = $dt['pay_term'];

?>
<body>
	<table class="table table-bordered table-sm">
			<tr>
				<th colspan="9"><center><?php echo $title;  } ?></center></th>
			</tr>
			<tr>
				<td colspan="4" rowspan="3">EXPORTER<br><b>DIVINE EXPORTS,<br>NO.16/W-4, ODAI STREET,<br>CUMBUM 625 516.<br>TAMIL NADU,INDIA.</b></td>
				<td colspan="3"><b>INVOICE NO <br>DE/22-23/005</b></td>
				<td colspan="2"><b>DATE <br>25.04.22</b></td>
			</tr>
			<tr>
				<td colspan="5"><center>BUYERS'S ORDER NO & DATE</center></td>
			</tr>
			<tr>
				<td colspan="5">OTHER REFERENCE(S) FROM SDF</td>
			</tr>
			<tr>
				<td colspan="4" rowspan="3">CONSIGNEE<br><b>S.K.T TRADERS PVT LTD.,</b><br>11/10, HAWWA PLAZA,<br>SEA STREET,<br>COLOMBO 11,<br><b>SRI LANKA</b></td>
				<td colspan="5">BUYER (IF OTHER THAN CONSIGNEE)<br><b>SAME AS CONSIGNEE</b></td>
			</tr>
			<tr>
				<td colspan="3"><center>COUNTRY OF ORIGIN OF GOODS</center></td>
				<td colspan="2"><center>COUNTRY OF FINAL DESTINATION</center></td>
			</tr>
			<tr>
				<td colspan="3"><center><b>INDIA</b></center></td>
				<td colspan="2"><center><b>SRILANKA</b></center></td>
			</tr>
			<tr>
				<td colspan="2">PRE-CARRIAGE BY</td>
				<td colspan="2">PLACE OF RECIPT BY</td>
				<td colspan="5" rowspan="3">PAYMENT TERM's<br><b>CIF COLOMBO BY SEA<br>100% ADVANCE TT</b></td>
			</tr>
			<tr>
				<td colspan="2">VESSEL/FRIEGHT NO</td>
				<td colspan="2">PORT OF LOADING<br><b>TUTICORIN, INDIA</b></td>
			</tr>
			<tr>
				<td colspan="2">PORT OF DISCHARGE<br><b>COLOMBO, SRILANKA</b></td>
				<td colspan="2">PLACE OF DELIVERY<br><b>COLOMBO, SRILANKA</b></td>
			</tr>
			<tr id="cen">
				<th>MARKS & NOS</th>
				<th>NO & KIND OF PACKAGES</th>
				<th colspan="4"><center>DESCRIPTION OF THE GOODS</center></th>
				<th>QUANTITY<br>Metric Tons</th>
				<th>RATE<br>USD/MT</th>
				<th>TOTAL<br>USD</th>
			</tr>
			<tr id="cen" class="bold">
				<td>LIRA 1 TO 560</td>
				<td>560 BAGS</td>
				<td colspan="4">RED CHILLIES MEDIUM 334</td>
				<td><center>14.000</center></td>
				<td><center>2100.00</center></td>
				<td><center>29400.00</center></td>
			</tr>
			<tr id="cen" class="bold">
				<td>LIRA 1 TO 560</td>
				<td>560 BAGS</td>
				<td colspan="4">RED CHILLIES MEDIUM 334</td>
				<td><center>14.000</center></td>
				<td><center>2100.00</center></td>
				<td><center>29400.00</center></td>
			</tr>
			<tr id="cen" class="bold">
				<td>LIRA 1 TO 560</td>
				<td>560 BAGS</td>
				<td colspan="4">RED CHILLIES MEDIUM 334</td>
				<td><center>14.000</center></td>
				<td><center>2100.00</center></td>
				<td><center>29400.00</center></td>
			</tr>						
			<tr>
				<td></td>
				<td></td>
				<td colspan="4">HS CODE : 09042110</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td>CIF VALUE :</td>
				<td colspan="3">USD.29400.00</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td>FREIGHT VALUE :</td>
				<td colspan="3">USD.1625.00</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td>INSURANCE :</td>
				<td colspan="3">USD.45.80</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td>FOB VALUE :</td>
				<td colspan="3">USD.27729.20</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td>TOTAL NO.OF.BAGS</td>
				<td>SL.NO. OF BAGS</td>
				<td>EACH BAG NET WT.(KGS)</td>
				<td>EACH BAG GROSS WT.(KGS)</td>	
				<td>TOTAL BAG GROSS WEIGHT (MTS)</td>
				<td>TOTAL BAG NET WEIGHT (MTS)</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td>560</td>
				<td>1 TO 560</td>
				<td>25.000</td>
				<td>26.200</td>
				<td>14.672</td>
				<td>14.000</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td colspan="3">FIVE HUNDRED AND SIXTY BAGS ONLY</td>
				<td colspan="3">PACKED IN JUTE BAGS ONLY</td>
				<td></td>
				<td></td> 
				<td></td>
			</tr>
			<tr>
				<td class="bold" rowspan="" colspan="3">BANKER DETAILS:<br>DBS BANK INDIA LIMITED,<br>NO.55,LOCAL FUND ROAD,<br>CUMBUM 625516.<br>CERTIFIED THAT GOODS ARE OF INDIAN ORIGIN.</td>
				<td rowspan="" colspan="3"><b>NAME : DIVINE EXPORTS<br>CC A/C NO:020336000002374<br>IFSC CODE:&nbsp;&nbsp;&nbsp;  DBSS01N0203</b><br>SWIFT CODE:&nbsp;&nbsp;LAVBINBBXXX<br>AD CODE: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;669003C</td>
				<td></td>
				<td></td> 
				<td></td>
			</tr>
			<tr>
				<td colspan="6">AMOUNT IN WORDS :</td>
				<td>14.000</td>
				<td></td> 
				<td>29400.00</td>
			</tr>
			<tr>
				<td colspan="9"><center>(USD TWENTY NINE THOUSAND AND FOUR HUNDRED ONLY)</center></td>
			</tr>
			<tr>
				<td class="bold" colspan="5">CONTAINER NO : (1 X 40'H FCL):</td>
				<td class="bold" rowspan="5" colspan="4">SIGNATURE<br><br><br><br><br><br><br>AUTHORISED SIGNATORY</td>
			</tr>
			<tr>	
				<td colspan="5">ARN : AD331221014502Y &nbsp; DT.24.12.21</td>
			</tr>
			<tr>
				<td colspan="2">IEC NO : BPKPK32744A</td>
				<td colspan="3">PAN NO : BPKPK32744A</td>

			</tr>
			<tr>
				<td colspan="5">GST NO : 33BPKPK3274A3Z6</td>
			</tr>
			<tr>
				<td colspan="5"><b>DECLARATION :</b><br>WE DECLARE THAT THIS INVOICE SHOWS THE ACTUAL PRICE OF THE GOODS DESCRIBED & THAT ALL PARTICULARS ARE TRUE AND CORRECT.</td>
			</tr>
	</table>					

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
</body>
</html>