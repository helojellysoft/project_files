
<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
$vid=$_POST['idno'];
$vname=$_POST['name'];
$vmobile=$_POST['mobile'];
$vemail=$_POST['email'];
$vaddress=$_POST['address'];
$vdistrict=$_POST['district'];
$vgst=$_POST['gst_no'];
// $vcountry=$_POST['country'];
// $vgst=$_POST['gst'];
$vremark=$_POST['remark'];
$qr="update ship1_party set name='$vname', gst='$vgst', mobile='$vmobile', email='$vemail', address='$vaddress', district='$vdistrict',remark='$vremark' where pidno='$vid'";
// echo$qr;
if ($conn->query($qr)==True){
// echo"Record ok inserted";
header("location:party_display.php");
}else{
echo"Error:" .$qr."<br>". $conn->error;
}
?>