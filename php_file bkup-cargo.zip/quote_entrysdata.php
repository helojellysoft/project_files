<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "insert";

$con = mysqli_connect("localhost", "root", "", "insert");
if($con == false){
	die("Error:Could'nt Connect".mysqli_connect_error());
}


$a1 = $_GET["jqdate"];
$a2 = $_GET["jqino"];
$a3 = $_GET["jqparticular"];
$a4 = $_GET["jqamount"];
$e1= $_GET["e1"];
$e2= $_GET["e2"];
$e3= $_GET["e3"];

$sql = "insert into tblquote (qdate, qino, qparticular, qamount,e1,e2,e3)values('$a1','$a2','$a3','$a4','$e1','$e2','$e3')";
echo$sql;

$res=mysqli_query($con,$sql);


//mysqli_close($conn);

?>