<?php
include'dbconfig.php';
$conn = opencon();
// echo"db connected";
$vbno = $_GET['jbno'];
$vt1 = $_GET['japart'];
$vt2 = $_GET['ja_amt'];
$vt3 = $_GET['ja_hsn'];
$vt4 = $_GET['jex1'];


echo$vt2;
for ($i=0; $i<count($vt2); $i++)
{
      $query="insert into tbltaxdetails(tbno,tpart,tamt,hsn,ex_bno1,tax_info)values('$vbno','$vt1[$i]','$vt2[$i]','$vt3[$i]','$vt4','0')";
      echo$query;
      $qrexe = $conn->query($query);

    // $upqr = "select * from tblstock where tagno = '$vt2[$i]'";
    // echo$upqr;
    // $upqrexe = $conn->query($upqr);
    // while($feupqr = $upqrexe->fetch_assoc())
    // {
    //     if($vt1[$i]=='Gold'){
    //     $fup = $feupqr['netwt'];        
    //     $newqty = $fup - $vt6[$i];    
    //     $setqr = "update tblstock set netwt='$newqty' where tagno='$vt2[$i]'"; 
    //     }
    //     elseif($vt1[$i]=='Silver'){
    //     $fup = $feupqr['grwt'];   
    //     $newqty = $fup - $vt4[$i];       
    //     $setqr = "update tblstock set grwt='$newqty' where tagno='$vt2[$i]'";  
    //     }
    //     echo$setqr;
    // }

    // echo"New stock=".$newqty;
    // $setqr = "update tblstock set grwt='$newqty' where tagno='$vt2[$i]'";
    // echo$setqr;
    // $setqrexe = $conn->query($setqr);
}
// header('Location: sales_print.php?bno=$vbno');
// echo"working";
?>