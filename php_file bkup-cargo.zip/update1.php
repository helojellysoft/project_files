<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert1";
$conn=new mysqli($server,$username,$password,$dbname);
$pid=$_POST['sno'];
$vname=$_POST['name'];
$vmobile=$_POST['mobile'];
$vemail=$_POST['email'];
$vaddress=$_POST['address'];
$vdistrict=$_POST['district'];
$vstate=$_POST['state'];
$vcountry=$_POST['country'];
$vgst=$_POST['gst'];
$vremark=$_POST['remark'];
$qr="update ship1 set name='$vname',mobile='$vmobile',email='$vemail' ,address='$vaddress', district='$vdistrict',state='$vstate',country='$vcountry',gst='$vgst',remark='$vremark' where sno='$pid'";
if ($conn->query($qr)==True) {
// echo$qr;
header("location:add-library-assets.php");
  }else

 {
  echo "Error:" .$qr. "<br>".$conn->error;
  }
?>