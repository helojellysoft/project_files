
<?php
// include'dbconfig.php';
// $conn = opencon();


$servername = "localhost"; //localhost
$username = "root"; //usrname
$password = ""; //password
$db = "insert";
$conn = new mysqli($servername, $username, $password, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// return $conn;


echo"db connected";






$vt1 = $_GET["jbdate"];
$vt2 = $_GET["jbno"];				//bno1
$vt3 = $_GET['jbper'];
$vt4 = $_GET['jbto'];
$vt5_temp = $_GET['jbpartsingle'];

$vt5 = str_replace("'","\'",$vt5_temp);


echo"String Replace";


$ex1 = $_GET['jex1'];				//bno2
$ex2 = $_GET['jex2'];
$ex3 = $_GET['jex3'];				//bno3  
$ex4 = $_GET['jex4'];

$query="insert into tbltaxbill(tbdate,tbno,tbto,tbper,tbpart,ex_bno1,ex_dt1,ex_bno2,ex_dt2,ex_status)values ('$vt1','$vt2','$vt3','$vt4','$vt5','$ex1','$ex2','$ex3','$ex4','0')";
echo$query;
$qrexe = $conn->query($query);



// // echo"working";
$query21="insert into tblin_pay_history(pdate,pbno,amt)value('$vt1,'$vt2','0')";;
// echo$query21;
$qrexe21 = $conn->query($query21);

?>