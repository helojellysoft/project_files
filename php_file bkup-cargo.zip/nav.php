<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>AARON Infotech-ERP2</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- googl icons
        ============================================ -->    
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />

    <!-- favicon
		============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- owl.carousel CSS
		============================================ -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- meanmenu icon CSS
		============================================ -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- main CSS
		============================================ -->
    <link rel="stylesheet" href="css/main.css">
    <!-- educate icon CSS
		============================================ -->
    <link rel="stylesheet" href="css/educate-custon-icon.css">
    <!-- morrisjs CSS
		============================================ -->
    <link rel="stylesheet" href="css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
		============================================ -->
    <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
    <!-- calendar CSS
		============================================ -->
    <link rel="stylesheet" href="css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="css/calendar/fullcalendar.print.min.css">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="style.css">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- modernizr JS
		============================================ -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>
<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    <!-- Start Left menu area -->
    <div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="dashboard.php"><img class="main-logo" src="img/logo/opop.png" alt="" /></a>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
       <!--                   <li>
                            <a title="Landing Page" href="index-1.php" aria-expanded="false"><span class="educate-icon educate-apps icon-wrap" aria-hidden="true"></span> <span class="mini-click-non">Dashboard</span></a>
                        </li> -->

                        <li>
                            <a title="Landing Page" href="dashboard.php" aria-expanded="false"><span class="educate-icon educate-event icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Dashboard</span></a>
                        </li>


                         <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><span class="educate-icon educate-form icon-wrap"></span> <span class="mini-click-non">Importer</span></a>
                            <ul class="submenu-angle form-mini-nb-dp" aria-expanded="false">
                                
                               
                                <li><a title="Multi Upload" href="importer_entry.php"><span class="mini-sub-pro">New</span></a></li>
                                 <li><a title="Password Meter" href="importer_display.php"><span class="mini-sub-pro">Edit/Delete</span></a></li>
                            </ul>
                        </li>

                         <li>
                            <a class="has-arrow" href="all-courses.html" aria-expanded="false"><span class="educate-icon educate-library icon-wrap"></span> <span class="mini-click-non">Exporter</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Library" href="exporter_entry.php"><span class="mini-sub-pro">New</span></a></li>
                                <li><a title="Add Library" href="exporter_display.php"><span class="mini-sub-pro">Edit/Delete</span></a></li>
                            </ul>
                        </li>
                         <li>
                            <a class="has-arrow" href="all-courses.html" aria-expanded="false"><span class="educate-icon educate-library icon-wrap"></span> <span class="mini-click-non">Buyer/Notify</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Library" href="buyer_entry.php"><span class="mini-sub-pro">New</span></a></li>
                                <li><a title="Add Library" href="buyer_display.php"><span class="mini-sub-pro">Edit/Delete</span></a></li>
                            </ul>
                        </li>
                         <li>
                            <a class="has-arrow" href="all-courses.html" aria-expanded="false"><span class="educate-icon educate-library icon-wrap"></span> <span class="mini-click-non">Party Name</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Library" href="party_entry.php"><span class="mini-sub-pro">New</span></a></li>
                                <li><a title="Add Library" href="party_display.php"><span class="mini-sub-pro">Edit/Delete</span></a></li>
                            </ul>
                        </li>                                                
<!--                         <li>
                            <a title="Landing Page" href="events.php" aria-expanded="false"><span class="educate-icon educate-event icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Quotations</span></a>
                        </li> -->
                          <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><span class="educate-icon educate-data-table icon-wrap"></span> <span class="mini-click-non">Quotation</span></a>
                            <ul class="submenu-angle app-mini-nb-dp" aria-expanded="false">
                                <li><a title="Notifications" href="quote_newentry.php"><span class="mini-sub-pro">New Entry</span></a></li>
                                <li><a title="Alerts" href="quote_display.php"><span class="mini-sub-pro">Show list</span></a></li>
                            </ul>
                        </li>
                         <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><span class="educate-icon educate-form icon-wrap"></span> <span class="mini-click-non">Certificate(origin)</span></a>
                            <ul class="submenu-angle form-mini-nb-dp" aria-expanded="false">
                                
                               
                                <li><a title="Multi Upload" href="coo_entry.php"><span class="mini-sub-pro">New</span></a></li>
                                 <li><a title="Password Meter" href="coo_display.php"><span class="mini-sub-pro">Edit/Delete</span></a></li>
                            </ul>
                        </li>
                          <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><span class="educate-icon educate-apps icon-wrap"></span> <span class="mini-click-non">Invoice</span></a>
                            <ul class="submenu-angle app-mini-nb-dp" aria-expanded="false">
                                <li><a title="Notifications" href="invoice_entry.php"><span class="mini-sub-pro">CIF/C&F Bill</span></a></li><!-- 
                                <li><a title="Notifications" href="invoice_entry.php"><span class="mini-sub-pro">CIF Bill</span></a></li>
                                <li><a title="Notifications" href="invoice_entry.php"><span class="mini-sub-pro">C&F Bill</span></a></li> -->                                
                                <li><a title="Alerts" href="invoice_display.php"><span class="mini-sub-pro">View List</span></a></li>
                            </ul>
                        </li>
<!--                         <li>
                            <a title="Landing Page" href="professor-profile.php" aria-expanded="false"><span class="educate-icon educate-professor icon-wrap" aria-hidden="true"></span> <span class="mini-click-non">GST Bill</span></a>
                             </li>
                                <li>
                            <a title="Landing Page" href="google-map.php" aria-expanded="false"><span class="educate-icon educate-interface icon-wrap" aria-hidden="true"></span> <span class="mini-click-non">Shipment</span></a>
                             </li>
                                <li>
                            <a title="Landing Page" href="add-student.php" aria-expanded="false"><span class="educate-icon educate-student icon-wrap" aria-hidden="true"></span> <span class="mini-click-non">GST</span></a>
                        </li> -->
                         <li id="removable">
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-pages icon-wrap"></span> <span class="mini-click-non">Tax / Non-tax</span></a>
                            <ul class="submenu-angle page-mini-nb-dp" aria-expanded="false">
                                <li><a title="Login" href="nontax.php"><span class="mini-sub-pro">Bill of supply entry</span></a></li>
                                <li><a title="Register" href="nontax_display.php"><span class="mini-sub-pro">Bill of supply list</span></a></li>                                
                                <li><a title="Login" href="taxable.php"><span class="mini-sub-pro">Taxable entry</span></a></li>                                
                                <li><a title="Register" href="taxable_display.php"><span class="mini-sub-pro">Taxable list</span></a></li>                                
                            </ul>
                        </li>
                         <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><span class="educate-icon educate-data-table icon-wrap"></span> <span class="mini-click-non">Outgoing</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                 <li><a title="Advance Form Elements" href="outgoing_entry.php"><span class="mini-sub-pro">New</span></a></li>

                                <li><a title="Data Table" href="outgoing_display.php"><span class="mini-sub-pro">Edit/Update</span></a></li>
                            </ul>
                        </li>                        
                         <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><span class="educate-icon educate-charts icon-wrap"></span> <span class="mini-click-non">Payment</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
          <!--                        <li><a title="Advance Form Elements" href="in_pay_entry.php"><span class="mini-sub-pro">Incoming Payment</span></a></li> -->
                                 <li><a title="Advance Form Elements" href="in_pay_display.php"><span class="mini-sub-pro">Incoming Details</span></a></li>

                                <li><a title="Data Table" href="out_pay_entry.php"><span class="mini-sub-pro">Outgoing Payment</span></a></li>
                                 <li><a title="Advance Form Elements" href="out_pay_display.php"><span class="mini-sub-pro">Outgoing Details</span></a></li>

                            </ul>
                        </li>
                         <li>
                            <a title="Landing Page" class ="has-arrow" href="report.php" aria-expanded="false"><span class="educate-icon educate-course icon-wrap" aria-hidden="true"></span> <span class="mini-click-non">Report</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                 <li><a title="Advance Form Elements" href="report_date.php"><span class="mini-sub-pro">By Date</span></a></li>

                                <!--<li><a title="Data Table" href="https://www.csshint.com/wp-content/uploads/2018/04/notify.jpg"><span class="mini-sub-pro">Exporterwise</span></a></li>
                                <li><a title="Data Table" href="https://www.csshint.com/wp-content/uploads/2018/04/notify.jpg"><span class="mini-sub-pro">By cargo</span></a></li>-->  

                                <li><a title="Data Table" href="gst_filing.php"><span class="mini-sub-pro">GST Filing</span></a></li>

                                <li><a title="Data Table" href="nongst_filing.php"><span class="mini-sub-pro">Bill of Supply</span></a></li>                                                                                          
                            </ul>                            
                        </li>
<!--                          <li>
                            <a title="Landing Page" href="departments.php" aria-expanded="false"><span class="educate-icon educate-department icon-wrap" aria-hidden="true"></span> <span class="mini-click-non">Settings</span></a>
                        </li>
 -->                    </ul>
                </nav>
            </div>
        </nav>
    </div>
     <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo" src="img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
                                                    <i class="educate-icon educate-nav"></i>
                                                </button>
                                        </div>
                                    </div>
                                   <!--  <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        <div class="header-top-menu tabl-d-n">
                                            <ul class="nav navbar-nav mai-top-nav">
                                                <li class="nav-item"><a href="#" class="nav-link">Home</a>
                                                </li>
                                                <li class="nav-item"><a href="#" class="nav-link">About</a>
                                                </li>
                                                <li class="nav-item"><a href="#" class="nav-link">Services</a>
                                                </li>
                                                <li class="nav-item dropdown res-dis-nn">
                                                    <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">Project <span class="angle-down-topmenu"><i class="fa fa-angle-down"></i></span></a>
                                                    <div role="menu" class="dropdown-menu animated zoomIn">
                                                        <a href="#" class="dropdown-item">Documentation</a>
                                                        <a href="#" class="dropdown-item">Expert Backend</a>
                                                        <a href="#" class="dropdown-item">Expert FrontEnd</a>
                                                        <a href="#" class="dropdown-item">Contact Support</a>
                                                    </div>
                                                </li>
                                                <li class="nav-item"><a href="#" class="nav-link">Support</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div> -->
                                    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                                    <div role="menu" class="author-message-top dropdown-menu animated zoomIn">
                                                        <div class="message-single-top">
                                                        
                                                        </div>
                                                       
                                                                    <div class="message-img">
                                                                       
                                                                    </div>
                                                                    <div class="message-content">
                                                                        
                                                                    </div>
                                                             
                                                                    <div class="message-img">
                                                                       
                                                                    </div>
                                                                    <div class="message-content">
                                                                        
                                                                    </div>

                                                               
                                                                    <div class="message-img">
                                                                       
                                                                    </div>
                                                                    <div class="message-content">
                                                                        
                                                                    </div>
                                                            
                                                                    <div class="message-img">
                                                                       
                                                                    </div>
                                                                    <div class="message-content">
                                                                        
                                                                    </div>
                                                                
                                                        <div class="message-view">
                                                           
                                                        </div>
                                                    </div>
                                                </li>
                                              
                                                    <div role="menu" class="notification-author dropdown-menu animated zoomIn">
                                                        <div class="notification-single-top">
                                                           </div>
                                                           
                                                                    <div class="notification-icon">
                                                                       
                                                                    </div>
                                                                    <div class="notification-content">
                                                                        
                                                                    </div>
                                                               
                                                              
                                                                    <div class="notification-icon">
                                                                       
                                                                    </div>
                                                                    <div class="notification-content">
                                                                    </div>
                                                              
                                                              
                                                                    <div class="notification-icon">
                                                                    </div>
                                                                    <div class="notification-content">
                                                                       
                                                                    </div>
                                                              
                                                              
                                                                    <div class="notification-icon">
                                                                    </div>
                                                                    <div class="notification-content">
                                                                       
                                                            </div>
                                                        <div class="notification-view">
                                                          
                                                        </div>
                                                    </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
              <!-- jquery
        ============================================ -->
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- wow JS
        ============================================ -->
    <script src="js/wow.min.js"></script>
    <!-- price-slider JS
        ============================================ -->
    <script src="js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
        ============================================ -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
        ============================================ -->
    <script src="js/counterup/jquery.counterup.min.js"></script>
    <script src="js/counterup/waypoints.min.js"></script>
    <script src="js/counterup/counterup-active.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
        ============================================ -->
    <script src="js/metisMenu/metisMenu.min.js"></script>
    <script src="js/metisMenu/metisMenu-active.js"></script>
    <!-- morrisjs JS
        ============================================ -->
    <script src="js/morrisjs/raphael-min.js"></script>
    <script src="js/morrisjs/morris.js"></script>
    <script src="js/morrisjs/morris-active.js"></script>
    <!-- morrisjs JS
        ============================================ -->
    <script src="js/sparkline/jquery.sparkline.min.js"></script>
    <script src="js/sparkline/jquery.charts-sparkline.js"></script>
    <script src="js/sparkline/sparkline-active.js"></script>
    <!-- calendar JS
        ============================================ -->
    <script src="js/calendar/moment.min.js"></script>
    <script src="js/calendar/fullcalendar.min.js"></script>
    <script src="js/calendar/fullcalendar-active.js"></script>
    <!-- plugins JS
        ============================================ -->
    <script src="js/plugins.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="js/main.js"></script>
    <!-- tawk chat JS
        ============================================ -->
    <!-- <script src="js/tawk-chat.js"></script> -->
</body>

</html>