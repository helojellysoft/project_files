<!doctype html>
<html class="no-js" lang="en">
 <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  </head>
<body>
    <?php
    include("nav.php");
    $server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
$quote_no=$_REQUEST['bno'];
$qr=mysqli_query($conn,"select * from tbltaxbill where tbno='$quote_no' and ex_status='1'");
while($dt=mysqli_fetch_array($qr))
{
    $tbno = $dt['tbno']; 
?>     
    
       
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
  </body>
  <body>
    <center>
<div class="alert alert-primary" role="alert">
 TAXABLE
</div>
</center>
<div class="alert alert-secondary" role="alert">
    <center>
 Please fill in the information below.The field labels marked with* are required input fields.</center>
</div>
<div class="alert alert-success" role="alert" style="background-color:#FAD8BA">
<div class="container overflow-hidden">
<div class="row">
  <div class="col">
    DATE :
    <input type="date" value="<?php echo date('Y-m-d'); ?>" value="<?php echo$dt['tbdate']; ?>"  class="form-control" id="txtdate">
  </div>
  <div class="col">
    BILL NO :


   <input type="hidden" value="<?php echo$dt['tbno'];  ?>" class="form-control" id="txtbno_hidden">

    <input type="text" value="<?php echo$dt['tbno'];  ?>" class="form-control" id="txtbno">
  </div>
   <div class="col">
    To :
 <div class="form-select-list">
      <select class="form-control custom-select-value" name="account" id="txt_to">
        <option value="<?php echo$dt['tbno'];  ?>"> <?php echo$dt['tbto'];  ?></option>
<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);
$qr1=mysqli_query($conn,"select distinct(name) from ship1_party where name!=''");
while($dt1=mysqli_fetch_array($qr1))
{        
  ?>
        <option value="<?php echo$dt1['name']; ?>"><?php echo$dt1['name']; } ?></option>
        <!-- <option>Select 3</option> -->
        <!-- <option>Select 4</option> -->
      </select><a href="party_entry_taxable.php">+ AddNew</a>
    </div>
  </div>
</div>
</div>
</div>
<br>
<div class="alert alert-primary" role="alert">
    <div class="alert alert-secondary" role="alert">
    <center>Please Select these before adding any product.</center>
    </div>
<div class="row">
  <div class="col">
    Shipped Per :
      <input type="text" value="<?php echo$dt['tbper'];   ?>" class="form-control" id="txtper"> 
  </div>
  <div class="col">
    Particular of cargo :
    <input type="text"  value="<?php echo$dt['tbpart']; ?>"  class="form-control" id="txtpartsingle"> 
  </div>

</div>
  <div class="col">
    Under S.B/B.E.No :
      <input type="text" value="<?php echo$dt['ex_bno1']; ?>"  class="form-control" id="ex_1"> 
  </div>
  <div class="col">
    Date :
    <input type="date" value="<?php echo date('Y-m-d'); ?>" value="<?php echo$dt['ex_dt1'];   ?>" class="form-control" id="ex_2"> 
  </div>
  <div class="col">
    Invoice No :
      <input type="text" value="<?php echo$dt['ex_bno2']; ?>"  class="form-control" id="ex_3"> 
  </div>
  <div class="col">
    Date :
    <input type="date"  value="<?php echo date('Y-m-d'); ?>" value="<?php echo$dt['ex_dt2']; } ?>" class="form-control" id="ex_4"> 
  </div>

</div>
 <div class="alert alert-success" role="alert">
  <div class="container overflow-hidden">
  <div class="row">
  <div class="col">
    Particular :
   <input type="text" class="form-control" id="txtpart">
  </div>
<div class="col">
       HSN :
    <input type="text" class="form-control" id="txthsn">
</div>  
<div class="col">
       Amount :
    <input type="text" class="form-control" id="txtamt">
</div>
<div class="col">
  <br>
    <input class="btn btn-primary" type="submit" value="Next" id="btnnext"> 
</div>
</div>
</div>
</div>
<br>
<br>
<div class="alert alert-danger" role="alert">
  <table class="table" id="table">
  <thead>
    <tr>
      <th scope="col">S.No</th>
      <th scope="col">Particular</th>
      <th scope="col">HSN</th>      
      <th scope="col">Amount</th>
       <!-- <th scope="col">EDIT</th> -->
       <th scope="col">DELETE</th>

    </tr>
  </thead>

   <?php
$c=0;
$s=0;
$qr2=mysqli_query($conn,"select * from tbltaxdetails where tbno='$quote_no' and tax_info='1'");
while($dt2=mysqli_fetch_array($qr2))
{
    $c=$c+1;
    // $tbno = $dt2['qino'];
     $s=$s+$dt2['tamt'];
?>
  <!-- <tbody> -->

<tr>
  <td><?php echo$c; ?></td>
  <td class='ct1' contenteditable="true"><?php echo$dt2['tpart']; ?></td>
  <td class='ct3' contenteditable="true"><?php echo$dt2['hsn']; ?></td>
  <td  class='ct2' contenteditable="true"><?php echo$dt2['tamt'];  ?></td>
  <td id='tdfirst'><span class='material-symbols-outlined' style='font-size:2em;'>delete</span></td>
</tr>
<?php 

}
?>

    <!--    <tr>
   <td>-</td>
      <td>-</td>
      <td>-</td>
      <td><svg xmlns="http://www.w3.org/2000/svg" width="30" height="50" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg></td>
      <td><svg xmlns="http://www.w3.org/2000/svg" width="30" height="50" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
  <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z"/>
</svg></td>
    </tr>
    <tr>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td><svg xmlns="http://www.w3.org/2000/svg" width="30" height="50" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg></td>
      <td><svg xmlns="http://www.w3.org/2000/svg" width="30" height="50" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
  <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z"/>
</svg></td>
    </tr> -->
  <!-- </tbody> -->
</table>
<div class="row">
  <div class="col">
   
      <input type="hidden" class="form-control" id=""> 
  </div>
    <div class="col">
   Total :
      <input type="text" class="form-control" id="lbl_tot"> 
  </div>
</div>
</div>


 <div class="alert alert-success" role="alert">
  <div class="container overflow-hidden">
  <div class="row">
  <div class="col">
    CGST %:
   <input type="number" class="form-control" id="txtcgst">
  </div>
<div class="col">
    Amount:
    <input type="text" class="form-control" id="txtcgstamt">
</div>
<!-- <div class="col">
  <br>
    <input class="btn btn-primary" type="submit" value="Next" id="btnnext"> 
</div> -->
</div>
<br><br>

  <div class="row">
  <div class="col">
    SGST %:
   <input type="number" class="form-control" id="txtsgst">
  </div>
<div class="col">
    Amount:
    <input type="text" class="form-control" id="txtsgstamt">
</div>
<!-- <div class="col">
  <br>
    <input class="btn btn-primary" type="submit" value="Next" id="btnnext"> 
</div> -->
</div>
<br><br>


 <div class="row">
  <div class="col">
    IGST %:
   <input type="number" class="form-control" id="txtigst">
  </div>
<div class="col">
    Amount:
    <input type="text" class="form-control" id="txtigstamt">
</div>
<!-- <div class="col">
  <br>
    <input class="btn btn-primary" type="submit" value="Next" id="btnnext"> 
</div> -->
</div>
<br><br>

</div>
</div>
  <div class="col">
    <br>
  <center><input class="btn btn-primary" type="submit" value="Submit" id="btnsave">
<input class="btn btn-primary" type="reset" value="Reset"></center>
</div>
</body>
<br>
<?php
include("fotter.php");
?>
</html>
<script type="text/javascript">
  $(document).ready(function(){
    var cnt=0;
    $("#btnnext").click(function(){
          //alert("hello");
      var count = $('#table tr').length;
      var jpart = $("#txtpart").val();
      var jamt = $("#txtamt").val();
      var jhsn = $("#txthsn").val();      
      cnt=cnt+1
      var x ="<tr id='tdfirst'><td>"+count+"</td><td class='ct1'>"+jpart+"</td><td class='ct3'>"+jhsn+"</td><td class='ct2'>"+jamt+"</td><td><span class='material-symbols-outlined' style='font-size:2em;'>delete</span></td></tr>";
      $(".table").append(x);

     var tot_gst = 0;
  $('.ct2').each(function(){
     tot_gst = parseInt($(this).text())+tot_gst;
    $("#lbl_tot").val(tot_gst);
  });
      $("#txtpart").val("");
      $("#txtamt").val("");
      $("#txtpart").focus();                        
    });



  });
</script>
<script>
$("table").on('click', '#tdfirst', function() {
    var currentRow = $(this).closest("tr");
    // alert("DOE");
    if (confirm('Are you sure ?')) {
        $(this).remove();
    }
    var  count = $('table tr').length;
    for(var i=0;i<count-1; i++){
    var x = document.getElementById("table").rows[i+1].cells;
    x[0].innerHTML = i+1;
    }

});
</script>

<script>
$(document).ready(function(){
 $("#btnsave").click(function(){   
  let gstbno = $("#ex_1").val();
  let g1 = $("#txtsgst").val();
  let g2 = $("#txtcgst").val();
  let g3 = $("#txtigst").val();
// alert("beforeajax");
    $.ajax({
      url: "gst_entry_sdata.php",
      method: "GET",
      data: {gstbno:gstbno, g1:g1, g2:g2, g3:g3},
      success:function(response){
          // alert("anbe sivam sgst=>" + gstbno);
          // window.location.href='taxable_display.php';
        
      }
  });  

 });
});  
</script>
<script>
$(document).ready(function(){
 $("#btnsave").click(function(){   
  // alert("working");
  let jbdate = $("#txtdate").val();
  let jbno = $("#txtbno").val();
  let jbno_hide = $("#txtbno_hidden").val();  
  let jbper = $("#txtper").val();
  let jbto = $("#txt_to").val();
  let jbpartsingle = $("#txtpartsingle").val();
  let jex1 = $("#ex_1").val();
  let jex2 = $("#ex_2").val();
  let jex3 = $("#ex_3").val();
  let jex4 = $("#ex_4").val();



if(jbno_hide!=jbno)
{
          let japart = [];
          let ja_amt= [];
          let ja_hsn= [];


           $('.ct1').each(function(){
            japart.push($(this).text());
          });
           //alert(japart);
         $('.ct2').each(function(){
            ja_amt.push($(this).text());
          });

          $('.ct3').each(function(){
            ja_hsn.push($(this).text());
          });
         
            $.ajax({
              url: "tax_entry_adata.php",
              method: "GET",
              data: {jbno:jbno, ja_hsn:ja_hsn, japart:japart, ja_amt:ja_amt, jex1:jex1},
              success:function(response){
                  //alert("anbe sivam=>" + jbno);
                  window.location.href='taxable_display.php';
                
              }
          });

             $.ajax({
                        url: "tax_entry_sdata_temp.php",
                        method: "GET",
                        data: {jbdate:jbdate, jbno:jbno, jbper:jbper, jbto:jbto, jbpartsingle:jbpartsingle, jex1:jex1, jex2:jex2, jex3:jex3, jex4:jex4,},

                        success:function(data){
                            //alert("2ndajax");
                           
                        }
                        });
}

if(jbno==jbno_hide){
  alert("Bill Number Already Here");
}
 });

});
</script>

<script>
$(document).ready(function(){
  $("#txtsgst").keyup(function(){
    var perc = $("#txtsgst").val();
    var temp = $("#lbl_tot").val();
    // alert(perc+","+temp);
    var ans = parseFloat(perc) * parseFloat(temp)*0.01;
    $("#txtsgstamt").val(ans);

  });

  $("#txtcgst").keyup(function(){
    var perc1 = $("#txtcgst").val();
    var temp1 = $("#lbl_tot").val();
    // alert(perc+","+temp);
    var ans1 = parseFloat(perc1) * parseFloat(temp1)*0.01;
    $("#txtcgstamt").val(ans1);

  });
  $("#txtigst").keyup(function(){
    var perc2 = $("#txtcgst").val();
    var temp2 = $("#lbl_tot").val();
    // alert(perc+","+temp);
    var ans2 = parseFloat(perc2) * parseFloat(temp2)*0.01;
    $("#txtigstamt").val(ans2);

  });  


});
</script>