


<?php
include'dbconfig.php';
$conn = opencon();
echo"db connected";
$vt1 = $_GET["jbdate"];
$vt2 = $_GET["jbno"];				//bno1
$vt3 = $_GET['jbper'];
$vt4 = $_GET['jbto'];
$vt5_temp = $_GET['jbpartsingle'];


$vt5 = str_replace("'","\'",$vt5_temp);



$ex1 = $_GET['jex1'];				//bno2
$ex2 = $_GET['jex2'];
$ex3 = $_GET['jex3'];				//bno3
$ex4 = $_GET['jex4'];

$query="insert into tbltaxbill(tbdate,tbno,tbto,tbper,tbpart,ex_bno1,ex_dt1,ex_bno2,ex_dt2,ex_status)values ('$vt1','$vt2','$vt4','$vt3','$vt5','$ex1','$ex2','$ex3','$ex4','1')";
echo$query;
$qrexe = $conn->query($query);



echo"working";
$query2="insert into tbltaxable_temp(temp_bno,temp_bno2,temp_bno3)values('$vt2','$ex1','$ex3')";
echo$query2;
$qrexe2 = $conn->query($query2);

?>