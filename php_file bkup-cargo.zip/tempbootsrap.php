<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<head>
    <link rel="stylesheet" href="css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="css/data-table/bootstrap-editable.css">
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th >Name</th>
            <th >Mobile No</th>
           	<th >Email</th>
            <th >Address</th>
            <th >District</th>
            <th >State</th>
            <th >Country</th>
            <th >GST No</th>
            <th >Remark</th>
            <th ></th>
            <th >Delete</th>
           </tr> 
		
	</table>

</body>
</html>