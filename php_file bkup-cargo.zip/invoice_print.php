<!DOCTYPE html>
<html>
<head>
	<title>INVOICE</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

<style type="text/css">
	*{
		font-size: 11px;
		text-transform: uppercase;
	}
	.bold{
		font-weight: bold;
	}
	#cen{
		text-align: center;
	}
	td, tr{
		border: 1px solid black;
	}
</style>

</head>
<body>
<?php
$server="localhost";
$username="root";
$password="";
$dbname="insert";
$conn=new mysqli($server,$username,$password,$dbname);


$pid=$_REQUEST['id'];
$qr=mysqli_query($conn,"select * from tblbill where bino='$pid'");
while($dt=mysqli_fetch_array($qr))
{
$n1 = 	$dt['bexporter'];
$n2 = 	$dt['bconsignee'];
$title = $dt['Inv_title'];
$dte = $dt['bdate'];
$prekg = $dt['borigin'];
$precpt = $dt['bdesign'];
$vsno = $dt['bvessno'];
$p_term = $dt['pay_term'];

?>
	<table class="table table-bordered table-sm">
			<tr>
				<th colspan="10"><center><?php echo $title;  } ?></center></th>
			</tr>
			<tr>
<?php
$qr2=mysqli_query($conn,"select * from ship1 where name='1'");
while($dt2=mysqli_fetch_array($qr2))
{
	?>

				<td colspan="5" rowspan="3">EXPORTER<br><b><?php echo strtoupper($dt2['name']); ?>,<br><?php echo strtoupper($dt2['address']); ?>,<br><?php echo strtoupper($dt2['district']); } ?>.<br>TAMIL NADU,INDIA.</b></td>
				<td colspan="3">INVOICE NO <b><?php echo$pid; ?></b></td>
				<td colspan="2">DATE <b><?php echo date("d/m/Y", strtotime($dte)); ?></b></td>
			</tr>
			<tr>
				<td colspan="5"><center>BUYERS'S ORDER NO & DATE</center></td>
			</tr>
			<tr>
				<td colspan="5">OTHER REFERENCE(S) FROM SDF</td>
			</tr>
<?php
$qr3=mysqli_query($conn,"select * from ship where name='$n2'");
while($dt3=mysqli_fetch_array($qr3))
{		
?>	
			<tr>
				<td colspan="5" rowspan="3">CONSIGNEE<br><b><?php echo $dt3['name']; ?>.,</b><br><?php echo$dt3['address']; ?>,<br><?php echo$dt3['district']; ?>,<br><?php echo$dt3['state']; ?>,<br><b><?php echo$dt3['country']; } ?></b></td>
				<td colspan="5">BUYER (IF OTHER THAN CONSIGNEE)<br><b>SAME AS CONSIGNEE</b></td>
			</tr>
			<tr>
				<td colspan="3"><center>COUNTRY OF ORIGIN OF GOODS</center></td>
				<td colspan="2"><center>COUNTRY OF FINAL DESTINATION</center></td>
			</tr>
			<tr>
				<td colspan="3"><center><b>INDIA</b></center></td>
				<td colspan="2"><center><b>SRILANKA</b></center></td>
			</tr>
			<tr>
				<td colspan="2">PRE-CARRIAGE BY<br><?php echo$prekg; ?></td>
				<td colspan="3">PLACE OF RECIPT BY<br><?php echo$precpt; ?></td></td>
				<td colspan="5" rowspan="3">PAYMENT TERM's<br><b><?php echo$p_term; ?></b></td>
			</tr>
			<tr>
				<td colspan="2">VESSEL/FRIEGHT NO<br><?php echo$vesno; ?></td>
				<td colspan="3">PORT OF LOADING<br><b>TUTICORIN, INDIA</b></td>
			</tr>
			<tr>
				<td colspan="2">PORT OF DISCHARGE<br><b>COLOMBO, SRILANKA</b></td>
				<td colspan="3">PLACE OF DELIVERY<br><b>COLOMBO, SRILANKA</b></td>
			</tr>
			<tr id="cen">
				<td>MARKS & NOS</td>
				<td></td>
				<td>NO & KIND OF PACKAGES</td>
				<td colspan="4"><center>DESCRIPTION OF THE GOODS</center></td>
				<td>QUANTITY<br>Metric Tons</td>
				<td>RATE<br>USD/MT</td>
				<td>TOTAL<br>USD</td>
			</tr>
<?php
$qr4=mysqli_query($conn,"select * from tbldetails where dino='$pid'");
while($dt4=mysqli_fetch_array($qr4))
{		
?>

			<tr id="cen" class="bold">
				<td><?php echo$dt4['dmno']; ?></td>
				<td rowspan="7"></td>
				<td><?php echo$dt4['dnpack'];  ?></td>
				<td colspan="4"><?php echo $dt4['dqty']; ?></td>
				<td><?php echo $dt4['dqty']; ?></td>
				<td><?php echo $dt4['drate']; } ?></td>
				<td>9000</td>
			</tr>
			<tr class="bold">
				<td rowspan="6"></td>
				<td>560 BAGS</td>
				<td colspan="4">RED CHILLIES MEDIUM 334</td>
				<td><center>14.000</center></td>
				<td><center>2100.00</center></td>
				<td><center>29400.00</center></td>
			</tr>
			<tr class="bold">
				<td rowspan="5"></td>
				<td colspan="4">HS CODE : 09042110</td>
				<td rowspan="10"></td>
				<td rowspan="10"></td>
				<td rowspan="10"></td>
			</tr>
			<tr class="bold">
				<td rowspan="">CIF VALUE:</td>
				<td rowspan="" colspan="3">USD.29400.00</td>
				
			</tr>
			<tr class="bold">
				<td>FREIGHT VALUE :</td>
				<td colspan="3">USD.1625.00</td>
			</tr>
			<tr class="bold">
				<td>INSURANCE</td>
				<td colspan="3">USD.45.80</td>				
			</tr>
			<tr class="bold">
				<td>FOB VALUE :</td>
				<td colspan="3">USD.27729.20</td>
			</tr>
			<tr class="bold" id="cen">
				<td></td>
				<td>TOTAL NO OF BAGS
				<td>SL.NO. OF BAGS</td>
				<td>EACH BAG NET WT.(KGS)</td>
				<td>EACH BAG GROSS WT.(KGS)</td>	
				<td>TOTAL BAG GROSS WEIGHT (MTS)</td>
				<td>TOTAL BAG NET WEIGHT (MTS)</td>
			</tr>
			<tr class="bold" id="cen">
				<td></td>
				<td>560</td>
				<td>1 TO 560</td>
				<td>25.000</td>
				<td>26.200</td>
				<td>14.672</td>
				<td>14.000</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td class="bold" rowspan="" colspan="4">FIVE HUNDRED AND SIXTY BAGS ONLY<br>BANKER DETAILS:<br>DBS BANK INDIA LIMITED,<br>NO.55,LOCAL FUND ROAD,<br>CUMBUM 625516.<br>CERTIFIED THAT GOODS ARE OF INDIAN ORIGIN.</td>
				<td rowspan="" colspan="3"><b>PACKED IN JUTE BAGS ONLY<br>NAME : DIVINE EXPORTS<br>CC A/C NO:020336000002374<br>IFSC CODE:&nbsp;&nbsp;&nbsp;  DBSS01N0203</b><br>SWIFT CODE:&nbsp;&nbsp;LAVBINBBXXX<br>AD CODE: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;669003C
			</tr>
			<tr>
				<td class="bold" colspan="7">AMOUNT CHARGABLE IN WORDS</td>
				<td id="cen"><b>14.000</b></td>
				<td></td>
				<td id="cen"><b>29400.00</b></td>
			</tr>
			<tr>
				<td colspan="10"><center><b>(USD TWENTY NINE THOUSAND AND FOUR HUNDRED ONLY)</b></center></td>
			</tr>
			<tr>
				<td class="bold" colspan="6">CONTAINER NO : (1 X 40'H FCL):<br>ARN : AD331221014502Y &nbsp; DT.24.12.21<br>IEC NO : BPKPK32744A &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PAN NO : BPKPK32744A<br> GST NO : 33BPKPK3274A3Z6</td>
				<td class="bold" rowspan="2" colspan="4">SIGNATURE<br><br><br><br><br><br>AUTHORISED SIGNATORY</td>
			</tr>
			<tr>
				<td colspan="6"><b>DECLARATION :</b><br>WE DECLARE THAT THIS INVOICE SHOWS THE ACTUAL PRICE OF THE GOODS DESCRIBED & THAT ALL PARTICULARS ARE TRUE AND CORRECT.</td>
			</tr>
	</table>			
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
</body>
</html>