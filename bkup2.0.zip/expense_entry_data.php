<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();


$ex_name = $_GET["ex_name"];
$ex_other = $_GET["ex_other"];
$ex_amount= $_GET["ex_amount"];
$ex_date = $_GET["ex_date"];
$ex_type = $_GET["ex_type"];
$ex_remark = $_GET["ex_remark"];
// $uname = $_GET["buname"];
// $pwd = $_GET["bpwd"];
// $status = $_GET["bstatus"];
// $group = $_GET["bgroup"];


$sql="insert into tblexpense(exp_name1,exp_name2,exp_amount,exp_date,exp_amount_type,exp_remark)values('$ex_name','$ex_other','$ex_amount','$ex_date','$ex_type','$ex_remark')";

echo$sql;

$result=mysqli_query($link,$sql);




?>