<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

echo"working..";
$promo_title = $_GET['promo_title'];
$promo_model = $_GET["promo_model"];
$promo_details = $_GET["promo_details"];
$promo_specs= $_GET["promo_specs"];
$promo_offer= $_GET["promo_offer"];
$promo_image= $_GET["promo_image"];
// echo"working".$group;

$sql="insert into tblpromotion(promo_title,promo_model,promo_details,promo_specs,promo_offer)values('$promo_title','$promo_model','$promo_details','$promo_specs','$promo_offer')";

echo$sql;


$result=mysqli_query($link,$sql);




?>