<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>receipt page</title>
    <link rel="stylesheet" href="receipt.css">
</head>
<body>
    <div class="main">
    <h3>RECEIPT</h3>
    <h2>SAKTHI COPIER</h2>
    <h4>H.O. : 17/S, Perumal South Car Street, Tirunelveli - 627 001</h4>
    <h4>B.O.:144E/15B, Kurunji Nagar Main Road, Near IVth Gate, Thoothukudi-2</h4>
    <h4>cell: 94431-72023, 99940-28206</h4>
    <div class="no"> No.</div><div class="date">Date :<?php echo"11-02-1990"; ?></div><br>
<?php 
$new_id = $_GET['id'];



include"no2text.php";

include "dbconnect.php";

$object = new db_conn();

$link=$object-> connection();

$qr=mysqli_query($link,"select * from tblpayment where id='$new_id'");
$ct=0;
// echo"helo batman::):  select * from tblpayment where pay_billno='$new_id'";
while($dt=mysqli_fetch_array($qr)){
$amt = $dt['pay_amt'];
 
// $tot_amt=1000;
$get_amount= AmountInWords($amt);

?>
    <p>Received with thanks form M/s. <span style="  border-bottom: 1px black dotted; margin:100px;"><?php echo$dt['pay_billno'];?> </p>
        <!-- <p>..................................................................................................................................................................................................................................................................</p> -->
        <p>the sum of Rupees <span style="margin:80px;"> <?php echo$get_amount."Only"; ?></span></p>
        <p>..................................................................................................................................................................................................................................................................</p>
        <p>towards <span style="margin:50px;"> <?php echo"\t\t BillNO:\t\t\t ".$dt['pay_billno'];  ?></span></p>
        <p>by Cash / Draft / Cheque ................................................... Bank</p>
        <p>No .............................................. Dated ..............................................</p>
        <small>(Cheque & Drafts subject to Reallsation)</small>
        <div class="box">For SAKTHI COPIER</div><br><br>
        <div class="box1">Rs.	&nbsp;	&nbsp;	&nbsp; <?php echo$dt['pay_amt']; } ?></div>
        <div class="box2">THANKS</div>
        <div class="box3"></div> 
    </div>
</body>
</html>