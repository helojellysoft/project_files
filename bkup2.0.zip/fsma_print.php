<!DOCTYPE html>
<html>
<head>
<style>
	body{
		font-family: "Times new roman"
	
	}
	div{
		overflow-x: auto;
	}
	table{
		border-collapse: collapse;
		border-spacing: 0;
		width: 100%;
		height:100%;
		border: 1px solid rgb(0,0,0);
	}
	th,td{
		text-align: left;
		padding: 8px;
		border: 1px solid black;
	}
	label{
		font-size: 1.5em;

	}
	p{
		font-size: 25px;
	}
	

</style>
</head>
<body>
	
	<table>
		
		<tr>
			<td rowspan="3"><label>Sakthi Copier</label><br>
			32 A,Subbaihpuram,2nd street,<br>
			Thoothukudi.<br>
			<b><i>Ph:94431 72023 / 90033 54099</i></b></td>
			<td colspan="2"><b>GSTIN : 33BOBPS2206C1ZL<br>
				PAN NO : BOBPS2206C<br>
			C.S.T.NO : 525925</td></b>
			<td colspan="2"><b> Dated :<br>
		01-06-2022</td></b>
		</tr>
		<tr>
			<td><b>Invoice / Bill No</b></td>
			<td><b>HSN / SAC</b></td>
			<td><b>Customer Code</b></td>
		</tr>
		<tr>
			<td>SC 001726</td>
			<td>9973</td>
			<td>DSA1001.010522</td>
			
		</tr>
		<tr>
			<td rowspan="2">M/s SUPERINTENDING ENGINEER,<br>
				P&A, RCS / TTPS,<br>
				Thoothukudi.3.<br>
			<b>GSTIN: 33AADCT4784E1ZC</b></td><br>
			<td colspan="2"><b>M/c Model No.</b></td>
			<td colspan="2"><b>M/c Serial No.</b></td>
		</tr>
		<tr>
			<td colspan="2">Canon iR 3035</td>
			<td>MUPI4923</td>
		</tr>
		<tr>
			<th>DESCRIPTION</th>
			<th>METER READING</th>
			<th>DATE OF READING</th>
			<th>AMOUNT</th>
		</tr>
		<tr>
			<td>MONTHLY RENTAL</td>
			<td></td>
			<td></td>
			<td><b>RS. 1,575.00</b></td>
		</tr>
		<tr>
			<td>Current month meter reading</td>
			<td>2,03,567</td>
			<td>31.05.2022</td>
			<td></td>
		</tr>
		<tr>
			<td>Last meter reading</td>
			<td>1,98,501</td>
			<td>01.05.2022</td>
			<td></td>
		</tr>
		<tr>
			<td>Gross Readings</td>
			<td>5,066</td>
			<td></td>
			<td></td>
		</tr>
		<tr>
			<td>Net Billable Copies</td>
			<td>5,066*0.31</td>
			<td></td>
			<td><b>Rs. 1,570.46</b></td>
		</tr>
		<tr>
			<td>Out put-State tax</td>
			<td>SGST-</td>
			<td>9%</td>
			<td><b>Rs. 283.09</b></td>
		</tr>
		<tr>
			<td>Out put-Central tax</td>
			<td>CGST-</td>
			<td>9%</td>
			<td><b>Rs. 283.09</b></td>
		</tr>
		<tr>
			<td>Charges @ Rs. 0.31 Per Copy</td>
			<td></td>
			<td>Rounded off add</td>
			<td><b>Rs. 0000.36</b></td>
		</tr>
		<tr>
			<td colspan="3">Total Amount</td>
			<td><b>Rs. 3,712.00</b></td>
		</tr>
		<tr>
			<td colspan="4">
				AMOUNT IN WORDS: Rupees Three Thousand Seven Hundred And Twelve Only
			</td>
		</tr>
		<tr>
			<td colspan="4"><b>*NOTE: OFFICE HOURS 10.00AM TO 6.00PM</b></td>
		</tr>
		<tr>
			<td colspan="1"><br>
				<br>
				<br>
				<br>
				<br>(Customer's Signature With Name and Stamp)</td>
			<td colspan="3"><b>Company Bank Details</b><br>
				Name: State Bank of India<br>
			Account Number: 31699658816<br>
			Branch IFSC Code: SBIN0014463<br>
			Branch: Thoothukudi.</td>
		</tr>
		<tr>
			<td colspan="2">PAYABLE TO <b><p>SAKTHI COPIER</b></p></td>
			<td rowspan="2" colspan="2"><b>FOR SAKTHI COPIER</b><br>
				<br>
				<br>
				<br>
				<br>
				<br>	
				<br>
				<br>
				AUTHORISED SIGNATURE
			</td>
		</tr>
		<tr>
			<td colspan="2">PLEASE PAY BY CROSSED CHEQUE / DEMAND DRAFT ONLY</td>
		</tr>
		</table>
</body>
</html>