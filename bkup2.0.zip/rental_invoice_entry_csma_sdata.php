<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();


// $status = $statusMsg = ''; 
// if(isset($_POST["submit"])){ 
//     $status = 'error'; 
//     if(!empty($_FILES["image"]["name"])) { 
//         // Get file info 
//         $fileName = basename($_FILES["image"]["name"]); 
//         $fileType = pathinfo($fileName, PATHINFO_EXTENSION); 
         
//         // Allow certain file formats 
//         $allowTypes = array('jpg','png','jpeg','gif'); 
//         if(in_array($fileType, $allowTypes)){ 
//             $image = $_FILES['image']['tmp_name']; 
//             $imgContent = addslashes(file_get_contents($image)); 
         
//             // Insert image content into database 
//             $insert = $db->query("INSERT into images (image, created) VALUES ('$imgContent', NOW())"); 
             
//             if($insert){ 
//                 $status = 'success'; 
//                 $statusMsg = "File uploaded successfully."; 
//             }else{ 
//                 $statusMsg = "File upload failed, please try again."; 
//             }  
//         }else{ 
//             $statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.'; 
//         } 
//     }else{ 
//         $statusMsg = 'Please select an image file to upload.'; 
//     } 
// } 
 
// // Display status message 
// echo $statusMsg; 


 $blno = $_POST["blno"];
 $date = $_POST["date"];
 $cname = $_POST["cname"];
 $code = $_POST["code"];
 $mdno = $_POST["mdno"];
 $seno = $_POST["seno"];
 $mread = $_POST["mread"];
 $dodate = $_POST["dodate"];
 $pread = $_POST["pread"];
 $pdate = $_POST["pdate"];
 $mrent = $_POST["mrent"];
 $sno2= $_POST["sno2"];
 $pcc = $_POST["pcc"];


 $sql="insert into tblnew_invoice_rental(inv_ren_bno,inv_ren_date, inv_ren_cname, inv_ren_code, inv_ren_mno,inv_ren_slno, inv_ren_mread,inv_ren_pread, inv_ren_mdate, inv_ren_pdate, inv_ren_month_rent, inv_ren_sno1, inv_ren_pcc)values('$blno','$date','$cname','$code','$mdno','$seno','$mread','$pread','$dodate','$pdate','$mrent','$sno2','$pcc')";
    

 echo$sql;

//  $result=mysqli_query($link,$sql);


if(mysqli_query($link, $sql)){
    header("location:rental_invoice_entry_csma.php?contact_name='hi'");
    echo "<script>alert('Records added successfully'); </script>";
    } else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }
    



//  if($result->query($sqr)==True){
		
//     header("location:stock_entry.php?contact_name='hi'");
// }
//  header("location:stock_entry.php");


// echo$sql;
// mysql_close($link);
?>