<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SAKTHI COPIER | Dashboard</title>
</head>
<style type="text/css">
  table{
    width: 100%;
    border-collapse: collapse;
  }

</style>
 <body>
<br>
<br>
<br>
<br>
<br>
<?php
include "crud.php";

$obj = new crud();

$id=1;//$_GET['id'];

$data=$obj->displayid("tblrent_quotation","rqto",$id);
// $ct=0;
foreach ($data as $get) {
// $ct=$ct+1;


 }
?> 
<br>
<br>
<br>
<br>
<br>
<br>
<span><b>GST IN:33BOPS2206C1ZL</b></span>
<span style="float: right;"><b>Date :22-apr</b> </span>
<center><span style="text-decoration:underline;"><b>QUOTAION</b></span></center>
<span>To:Party Name
  <!-- M/S. Blackstone Shipping Private Limited,<br>
  4 b/209 A,5th street, C.G.E.colony,<br>
  Tuticorin-628003. --></span><br>

<span><b> DEAR SIR,</b>
       <center><span><b>Sub: <?php echo "Om namasivaya";  ?></b></span></center>
      <label> As per the personal discussion we had with you please find enclose herewith the exclusive quote for you kind perusal.</label>
</span>
<br>

  <!-- <hr style="border-bottom:solid dark blue 1px;"> -->
    <table border="1">
  <thead>
    <tr>
      <th style="width:5% !important;">S.(No)</th>
      <th style="width:30% !important;">Product Description</th>
      <th >Permonth Rental amount  </th>
      <th >Permonth Free Copies</th>
      <th >Additionala copies over & above percopy</th>
      <th style="width:30% !important;" >Agreement Period</th>
      <th >Deposit Amount</th>
    </tr>
  </thead>


  <tbody class="table-group-divider">
    <tr>
      <td scope="row">Om</td>
      <td><?php echo "Enavo";?><!-- Copier + Network<br>Printer +
      color scanner(A4 Size)<br> ADF Duplex  --></td>
      <td> <?php echo "Arivila";?> </td>
      <td ><?php echo "voothukondu";?></td>
      <td><?php echo "thiruvarangam";?></td>
      <td><?php echo "Karuvarangam";?></td>
      <td>dep</td>
    </tr>
  </tbody>
  </table>  
    
    <label>Expecting your favourable reply and for further clarification please feel free to<br> contact us&nbsp;<b> 94431 72023/ 90033 54099.</b></label>
    <center><span>Assuring Best services at all times.</span></center>

    <span style="text-decoration:underline;float:left;"><b>TERMS & CONDITIONS</b></span><br>
    <ol style="float: left;">
      <li>Price : Add 18% Taxes.</li>
      <!-- <li>Advanced : 4 months(deposit) </li> -->
      <li>Payment : As per agreement</li>
      <li>Validity : 30 Days</li>
    </ol><br>
    <p style="float: right;">For<label style="font-size: 18px; color:solid blue;">&nbsp;Sakthi Copier</label><br><br><br> <label>Authorised Signature</label></p>
   
</body>
</html>