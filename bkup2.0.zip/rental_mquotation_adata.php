<?php
include 'dbconnect.php';
$object = new db_conn();

$link=$object-> connection();
$vbno = $_GET['qno'];
$vt1 = $_GET['ar1'];
$vt2 = $_GET['ar2'];
$vt3 = $_GET['ar3'];
$vt4 = $_GET['ar4'];
// echo$vt2;
for ($i=0; $i<count($vt2); $i++)
{
      $query="insert into tblspare_adata(spare_qno,spare_desc,spare_qty,spare_rate,spare_amount)
	  values('$vbno','$vt1[$i]','$vt2[$i]','$vt3[$i]','$vt4[$i]')";

    if(mysqli_query($link, $query)){
      // header("location:stock_entry.php?contact_name='hi'");
      // echo "<script>alert('Records added successfully'); </script>";
      echo$query;
      }
    //   $qrexe = $conn->query($query);

}
?>
