<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

$a1= $_POST["qno"];
$a2 = $_POST["qdate"];
$a3= $_POST["qto"];
$a4 = $_POST["qsub"];
$a5= $_POST["qdesc"];
$a6 = $_POST["qrent"];
$a7= $_POST["qfree"];
$a8 = $_POST["qadd"];
$a9= $_POST["qagree"];
$a10 = $_POST["qdeposit"];
// $a1= $_POST["qno"];
// $a2 = $_POST["qdate"];

$sql="insert into tblnew_quote_rental(qno,qdate,qto,qsubject,qdesc,qrental_amount,qfree_copies,qadditional,qaggrement,qdeposit)values
('$a1','$a2','$a3','$a4','$a5','$a6','$a7','$a8','$a9','$a10')";

echo$sql;
// $result=mysqli_query($link,$sql);


if(mysqli_query($link, $sql)){
    header("location:rental_quotation_entry.php?contact_name='hi'");
    echo "<script>alert('Records added successfully'); </script>";
    } else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }


?>