<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | General Form Elements</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
  
<?php
include 'nav.php';
?>  

<div class="content-wrapper">

<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Purchase</a></li>
              <li class="breadcrumb-item active">New Entry</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>


   <div class="card card-warning">
        <div class="card-header">
           <h3 class="card-title"> PURCHASE INVOICE ENTRY</h3>
        </div>
<form action="purchase_entry_new_sdata.php" method="POST"  enctype = "multipart/form-data">
          <div class="alert alert-light" role="alert" style="background">
        <div class="container overflow-hidden">
          <div class="card-body card-light">
           <div class="form-group row">
               <div class="col-sm-6">
                <label class="col-sm-2 col-form-label">Date :</label>
                <input type="date" class="form-control" value="<?php echo date('Y-m-d'); ?>" id="pur_date" name="pur_date">
              </div>

              <div class="col-sm-6">
                <label class="col-sm-6 col-form-label">Reference :</label>
                <input type="text" class="form-control" id="pur_ref" name="pur_ref">
              </div>
            </div>

            <div class="form-group row">
              <div class="col-sm-6">
                <label class="col-sm-8 col-form-label">Bill No :</label>
                <input type="text" class="form-control" name="pur_bill" id="pur_bill" required>
              </div>

            <div class="col-sm-6">
                <label class="col-sm-6 col-form-label">Supplier :</label>
                <!-- <input type="text" class="form-control"  id="pur_custom"> -->

                <select class="form-control custom-select-value" name="pur_custom" id="pur_custom">
        <option>- Select one -</option>
<?php
include 'dbconnect.php';

$object = new db_conn();

$conn=$object-> connection();
$qr1=mysqli_query($conn,"select distinct(bcompany) from tblbiller where bcompany!=''");
while($dt1=mysqli_fetch_array($qr1))
{        
  ?>
        <option value="<?php echo$dt1['bcompany']; ?>"><?php echo$dt1['bcompany']; } ?></option>

        
      </select>











              </div>
            </div>

            <div class="row">
              
               <div class="col-sm-4">
                <label for="ptype" class="col-sm-12 col-form-label">Details</label>
                    <div class="col-sm-12">
   <select class="form-control custom-select-value" name="account" id="detail">
        <option>- Select one -</option>
<?php
$qr11=mysqli_query($conn,"select distinct(pname) from tblstock where pname!=''");
while($dt11=mysqli_fetch_array($qr11))
{        
  ?>
        <option value="<?php echo$dt11['pname']; ?>"><?php echo$dt11['pname']; } ?></option>               
</select>
                    </div>
              </div>

              <div class="col-sm-4">
                <label class="col-sm-12 col-form-label">Rate :</label>
                <input type="text" name="" class="form-control"  id="pur_rate"> 
              </div>

                <div class="col-sm-4">
                <label class="col-sm-12 col-form-label">Quantity :</label>
                <input type="text" name="" class="form-control"  id="pur_qty"> 
              </div>

              

              <!-- <div class="col-sm-4">
                <label class="col-sm-6 col-form-label">D.O.Reading :</label>
                <textarea class="form-control" rows="3" id="doread"></textarea>
              </div> -->
            </div>
          </div>
            <input type="button" value="ADD" id="btnsave" class="btn btn-primary float-right">
          </div>

          <div class="card-body">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <!-- <th style="width: 10px;">S.N0</th> -->
                      <th>Details</th>
                      <th>Rate</th>
                      <th>Quantity</th>
                      <th style="width: 10px;">Delete</th>
                    </tr>
                  </thead>
                  <tbody id="empty">
                  </tbody>
                </table>
              </div><br>

               <div class="form-group row">
               <div class="col-sm-3">
                <label class="col-sm-6 col-form-label">CGST :</label>
                <input type="text" class="form-control" id="pur_cgst" name="pur_cgst">
              </div>

              <div class="col-sm-3">
                <label class="col-sm-6 col-form-label">SGST :</label>
                <input type="text" class="form-control" id="pur_sgst" name="pur_sgst">
              </div>

               <!-- <div class="col-sm-2">
                <label class="col-sm-12 col-form-label">Search :</label>
                <input type="text" class="form-control" id="search">
              </div> -->

              <div class="col-sm-3">
                <label class="col-sm-12 col-form-label">Upload Bill</label>
                <input type="file" class="form-control" id="pur_image" name="pur_image">
              </div>

              <div class="col-sm-3">
                <label class="col-sm-12 col-form-label">Other Charges :</label>
                <input type="text" class="form-control" id="pur_other" name="pur_other">
              </div>
            </div>

              <input type="submit" value="CONFIRM" id="btnconfirm" class="btn btn-primary float-right">
</form>
          </div>
      </div>
     </div>
    </div>
    


  <!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<!-- <script src="dist/js/demo.js"></script> -->
<!-- Page specific script -->
<script>
$(function () {
  bsCustomFileInput.init();
});
</script>
</body>
</html>

<script type="text/javascript">
  $(document).ready(function(){
    $("#btnsave").click(function(){
      var det = $("#detail").val();
      var rate = $("#pur_rate").val();
      var qty = $("#pur_qty").val();

      var x ="<tr><td class='b1'>"+det+"</td><td class='b2'>"+rate+"</td><td class='b3'>"+qty+"</td><td><i class='fa-solid fa-trash-can' id='y'></i></td><tr>";

      $("tbody").append(x);

       $("#detail").val("");
       $("#rate").val("");
       $("#quant").val("");
       $("#detail").focus();



    });
  });
</script>

<!-- <script type="text/javascript">
  $(document).ready(function(){
    $("#btnconfirm").click(function(){
      // alert("helo");
      var mrdate= $("#").val();
      var ref = $("#").val();
      var biller = $("#").val();
      var customer = $("#").val();
      var cgst = $("#").val();
      var sgst = $("#").val();
      // var search = $("#search").val();
      var scharge = $("#").val();
      // var pack = $("#pack").val();
      // alert(pack);

      $.ajax({
        url:"purchase_entry_new_sdata.php",
        method:"GET",
        data:{mrdate:mrdate, ref:ref, biller:biller, customer:customer, cgst:cgst, sgst:sgst, scharge:scharge},
        success:function(response){
          alert("rental m invoice s data collected");
        }
      });
      window.location.href="purchase_entry_new.php";




    });
  });
</script> -->

<script type="text/javascript">
  $(document).ready(function(){
    $("#btnconfirm").click(function(){
      // alert("array data working...");
      var bil= $("#pur_bill").val();
      var ar1 = [];
      var ar2 = []; 
      var ar3 = [];

      $(".b1").each(function(){
        ar1.push($(this).text());
      });
      // alert(ar1);

      $(".b2").each(function(){
        ar2.push($(this).text());
      });

      $(".b3").each(function(){
        ar3.push($(this).text());
      });
      // alert(ar3);

      $.ajax({
        url:"purchase_entry_new_adata.php",
        method:"GET",
        data:{bil:bil, ar1:ar1, ar2:ar2, ar3:ar3},
        success:function(response){
          alert("Purchase Entry saved successfully");
        }
      });

      // window.location.href="rental_minvoice_display.php";


    });
  });
</script>