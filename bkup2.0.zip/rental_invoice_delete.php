<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

$rid=$_REQUEST["id"];

$sql="Delete from tblnew_invoice_rental where inv_ren_bno='$rid'";
$res=mysqli_query($link,$sql) or die(mysqli_error());
echo$sql;
header("location:rental_invoice_display.php");


?>