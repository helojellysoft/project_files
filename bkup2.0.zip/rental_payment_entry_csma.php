<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SAKTHI COPIER | Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<?php
include 'nav.php';
?>


<?php
// include "crud.php";

// $obj = new crud();

// $id=5;//$_GET['id'];

// $data=$obj->displayid("tblbiller","bfname",$id);
// $ct=0;
// foreach ($data as $get) {
// $ct=$ct+1;



?> 
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Invoice Rental Payment Page</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <!-- /.card -->
            <!-- Horizontal Form -->
            <div class="card card-success">
              <div class="card-header">
                <h3 class="card-title">INVOICE: RENTAL PAYMENT ENTRY</h3>
              </div>
<?php 

include 'dbconnect.php';

$id=$_GET['id'];
// $pay_type =$_GET['pay_type']; 

$object = new db_conn();

$link=$object-> connection();

$qr=mysqli_query($link,"select * from tblnew_invoice_rental where inv_ren_bno='$id'");


while($dt=mysqli_fetch_array($qr)){

?>


              <!-- /.card-header -->
              <!-- form start -->
              <form class="form-horizontal">
                <div class="card-body">
                  <!-- <input type="text" id="paytype" value='<?php echo$pay_type; ?>'> -->
                  <div class="form-group row">
                    <label for="pname" class="col-sm-2 col-form-label">Bill Number</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="txtpay_billno" value="<?php echo$dt['inv_ren_bno']; ?>" id="fname" readonly>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Bill Date</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" disabled value="<?php echo $dt['inv_ren_date']; ?>" id="lname" placeholder="">
                    </div>
                  </div>


                   <div class="form-group row">
                    <label for="ptype" class="col-sm-2 col-form-label">Customer Name</label>
                    <div class="col-sm-10">
                      <select class="form-control" value="<?php echo "Mr.Bala";?>" disabled id="gender">
                          <option>-Select-</option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                      </select>
                      </div>
                  </div>

                   <div class="form-group row">
                    <label for="pcode" class="col-sm-2 col-form-label">Bill Amount </label>
                    <div class="col-sm-10">

<?php 
$gross_read = $dt['inv_ren_mread'] - $dt['inv_ren_pread'];


$tot_amt = $gross_read* 0.31;

$gst_amt = $dt['inv_ren_sgst']*0.01*$tot_amt;   

$gst_amt2 = $dt['inv_ren_cgst']*0.01*$tot_amt; 

$net_amt = $gst_amt + $gst_amt2 + $tot_amt;

}                  
?>

                      <input type="text" class="form-control" value="<?php echo "Rs.".$net_amt;?>" id="company" placeholder="" disabled>
                    </div>
                  </div>

                   <div class="form-group row">
                    <label for="pcode" class="col-sm-2 col-form-label">Payment Amount </label>
                    <div class="col-sm-10 input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-currency">Rs.</i></span>
                      <input type="text" class="form-control" value="" id="txtpay_amount" placeholder="">
                    </div>
                  </div>

                  <div class="form-group row">
                     <label for="pcode" class="col-sm-2 col-form-label">Payment Date</label>
                      <div class="col-sm-10 input-group-prepend">
                        <!-- <span class="input-group-text">@</span> -->
                        <input type="date" class="form-control"  id="txtpay_date" placeholder="">
                      </div>
                  </div>

                   <div class="form-group row">
                    <label for="pcode" class="col-sm-2 col-form-label">Payment Type </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="txtpay_mode" placeholder="">
                    </div>
                  </div>

                   <div class="form-group row">
                    <label for="pcode" class="col-sm-2 col-form-label"> Remarks </label>
                    <div class="col-sm-10">
                      <input type="Password" class="form-control" id="txtpay_remarks" placeholder="">
                    </div>
                  </div>

                


                  
                  <!-- </div> -->
                 
                <!-- /.card-body -->
                <!-- <div class="card-footer"> -->
                 
                  <input type="button" id="btnconfirm" value="RENTAL PAY" class="btn btn-info float-right">
                <!-- </div> -->
                <!-- /.card-footer -->
              </form>
            </div>
            <!-- /.card -->

          </div>
          <!--/.col (left) -->
          <!-- right column -->
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

 </body>
 </html>
 <script type="text/javascript">
   $(document).ready(function(){
      $("#btnconfirm").click(function(){
        // alert("hello");
        var pay_amount = $("#txtpay_amount").val();
        var pay_date = $("#txtpay_date").val();
        var pay_mode = $("#txtpay_mode").val();
        var pay_remarks = $("#txtpay_remarks").val();
        var pay_billno = $("#txtpay_billno").val();
        // var pay_type = $("#pay_type").val();
        
        // var bemail = $("#mail").val();
        // var buname = $("#uname").val();
        // var bpwd = $("#pwd").val();
        // var bstatus = $("#status").val();
        // var bgroup = $("#group").val();
         // alert(bgender);

        // alert(bgroup);


        $.ajax({

          url : "rental_payment_entry_data.php",
          method : "GET",
          data : {pay_billno:pay_billno, pay_amount:pay_amount, pay_date:pay_date, pay_mode:pay_mode, pay_remarks:pay_remarks},
          success : function(response){
            alert("biller data updated");
            
          }

        });
        window.location.href="sales_payment.php";


      });

    });

 </script>