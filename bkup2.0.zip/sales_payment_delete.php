<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

$rid=$_REQUEST["id"];



$sql="Delete from tblpayment where id='$rid'";
$res=mysqli_query($link,$sql) or die(mysqli_error());
echo$sql;
header("location:sales_payment.php");


?>