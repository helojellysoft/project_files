<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();

$rid=$_REQUEST["id"];

$sql="Delete from tblamc where amc_no='$rid'";
$res=mysqli_query($link,$sql) or die(mysqli_error());
echo$sql;
header("location:sales_invoice_display_amc.php");


?>