<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SAKTHI COPIER | Dashboard</title>
</head>
<style type="text/css">
  table{
    width: 100%;
    border-collapse: collapse;
  }
  #btm {
  margin-top:100px;
}
</style>
<body>
	<br>
<!-- <br>
<br>
<br>
<br> -->
<!-- <?php
// include "crud.php";

// $obj = new crud();

$id=$_GET['id'];

// $data=$obj->displayid("tblrent_quotation","rqto",$id);
// $ct=0;
// foreach ($data as $get) {
// $ct=$ct+1;



?>  -->
<br>
<!-- <br>
<br>
<br> -->
<img src="lpad_tp.jpg" alt=""><br><br><br>

<br>
<br>


<?php

include 'dbconnect.php';

$spareqno=$_GET['id'];

$object = new db_conn();

$link=$object-> connection();

$qr=mysqli_query($link,"select * from tblsparesdata where spare_qno='$spareqno'");

$ct=0;

while($dt=mysqli_fetch_array($qr)){


// }

?>
<span><b>GST IN:33BOBPS2206C1ZL </b></span>
<span style="float: right;"><b>Date :<?php echo$dt['spare_date'];  ?></b> <!-- <?php echo "Rate"; ?> --></span>
<center><span style="text-decoration:underline;"><b>QUOTAION</b></span></center><span style="float:right;"><b>Q.No:<?php echo$dt['spare_qno'];  ?> </b></span>
<span>To:
  M/S. <?php echo$dt['spare_to'];  ?>,<br>
  4 b/209 A,5th street, C.G.E.colony,<br>
  Tuticorin-628003.</span><br>

<span><b> DEAR SIR,</b>
       <center><span><b>Sub:<?php echo$dt['spare_subject']; } ?> </b></span></center>
      <label> As per the personal discussion we had with you please find enclose herewith the exclusive quote for you kind perusal.</label>
</span>
<br>


  <!-- <hr style="border-bottom:solid dark blue 1px;"> -->
    <table border="1">
  <thead>
    <tr>
      <th scope="col">S.(No)</th>
      <th scope="col">PARTICULARS</th>
      <th scope="col">QUANTITY</th>
      <th scope="col">RATE</th>
      <th scope="col">AMOUNT</th>
     
    </tr>
  </thead>
<!-- <?php
// $id1=$_GET['id'];

// $data1=$obj->displayid("tblrent_quotation_details","rqto",$id1);
// $ct=0;
// foreach ($data1 as $get1) {
// $ct=$ct+1;



?>  -->

<!-- ?> -->
  <tbody class="table-group-divider">
  <?php

$qr2=mysqli_query($link,"select * from tblspare_adata where spare_qno='$spareqno'");

$ct2=1;

while($dt2=mysqli_fetch_array($qr2)){
$s1 = $s1+$dt2['spare_amount'];

?>

  <tr>
      <td scope="row"> <?php echo$ct2; ?><!-- <?php echo "1"; ?> --></td>
      <td><?php echo$dt2['spare_desc']; ?></td>
      <td><?php echo$dt2['spare_qty']; ?> no </td>
      <td >Rs.<?php echo$dt2['spare_rate']; ?></td>
      <td>Rs.<?php echo$dt2['spare_amount']; } ?></td>
    </tr>

    <?php

$qr2=mysqli_query($link,"select * from tblsparesdata where spare_qno='$spareqno'");

$ct2=0;

while($dt2=mysqli_fetch_array($qr2)){
$s2 = $s1* $dt2['spare_sgst'] * 0.01;
$s3 = $s1* $dt2['spare_cgst'] * 0.01;

$tot_s = $s1+$s2+$s3;
?>



    <tr>
    	<td></td>
    	<td colspan="2" style="text-align: right;"><b>SGST@<?php echo$dt2['spare_sgst'];   ?>%<br>CGST@<?php echo$dt2['spare_cgst']; } ?>%</b></td>
    	<td></td>
    	<td>Rs.<?php echo$s2; ?><br>Rs.<?php echo$s3; ?></td>
    </tr>
    <tr>
    	<td></td>
    	<td colspan="2" style=""><center>Total</center></td>
    	<td></td>
    	<td>Rs.<?php echo$tot_s; ?></td>		
  </tbody>
  </table>  
    <br><br>
    <label>Expecting your favourable reply and for further clarification please feel free to<br> contact us&nbsp;<b> 94431 72023/ 90033 54099.</b></label>
    <center><span>Assuring Best services at all times.</span></center>
    <div id="btm">
    <span style="text-decoration:underline;float:left;"><b>TERMS & CONDITIONS</b></span><br>
    <ol style="float: left;">
      <li>Price : Add 18% Taxes.</li>
      <!-- <li>Advanced : 4 months(deposit) </li> -->
      <li>Payment : As per agreement</li>
      <li>Validity : 30 Days</li>
    </ol><br>
    <p style="float: right;">For<label style="font-size: 18px; color:blue;">&nbsp;Sakthi Copier</label><br><br><br> <label>Authorised Signature</label></p>
    <img src="lpad_btm.jpg"  alt="">
</div>
</body>
</html>