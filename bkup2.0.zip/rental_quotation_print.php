<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SAKTHI COPIER | Dashboard</title>
</head>
<style type="text/css">
  table{
    width: 100%;
    border-collapse: collapse;
  }
#btm {
  margin-top:150px;
}
</style>
 <body>
<!-- <br>
<br>
<br>
<br> -->
<br>
<?php
$id=$_GET['id'];
include "dbconnect.php";

$object = new db_conn();

$link=$object-> connection();

$qr=mysqli_query($link,"select * from tblnew_quote_rental WHERE qno='$id'");
$ct=0;

while($dt=mysqli_fetch_array($qr)){
$ct=$ct+1;
?>
<!-- <br> -->
<!-- <br>
<br>
<br>
<br>
<br> -->
<img src="lpad_tp.jpg" alt=""><br><br><br>
<span><b>GSTIN:33BOBPS2206C1ZL</b></span>
<span style="float: right;"><b>Date :<?php echo $dt['qdate'];  ?></b> </span><br>
<span style="float: right;"><b>Q.No:<?php echo $dt['qno'];  ?></b> </span>
<br><br>
<center><span style="text-decoration:underline;"><b>QUOTAION</b></span></center>
<span>To:
  M/S. <?php echo $dt['qto'];  ?>,<br>

	
	<!--
	
  4 b/209 A,5th street, C.G.E.colony,<br>
  Tuticorin-628003.</span><br>
--><br><br>
<span><b> DEAR SIR,</b><br><br>
       <center><span><b>Sub: <?php echo$dt['qsubject'];   ?></b></span></center><br>
      <label> As per the personal discussion we had with you please find enclose herewith the exclusive quote for you kind perusal.</label>
</span>
<br><br>

  <!-- <hr style="border-bottom:solid dark blue 1px;"> -->
    <table border="1">
  <thead>
    <tr>
      <th style="width:5% !important;">S.(No)</th>
      <th style="width:30% !important;">Product Description</th>
      <th >Permonth Rental amount  </th>
      <th >Permonth Free Copies</th>
      <th >Additionala copies over & above percopy</th>
      <th style="width:30% !important;" >Agreement Period</th>
      <th >Deposit Amount</th>
    </tr>
  </thead>


  <tbody class="table-group-divider">
    <tr>
      <td scope="row"><?php echo$ct; ?></td>
      <td><?php echo$dt['qdesc'];?><!-- Copier + Network<br>Printer +
      color scanner(A4 Size)<br> ADF Duplex  --></td>
      <td> <?php echo$dt['qrental_amount'];?> </td>
      <td ><?php echo$dt['qfree_copies'];?></td>
      <td><?php echo$dt['qadditional'];?></td>
      <td><?php echo$dt['qaggrement'];?></td>
      <td><?php echo$dt['qdeposit'];  } ?></td>
    </tr>
  </tbody>
  </table>  <br>
    
    <label>Expecting your favourable reply and for further clarification please feel free to<br> contact us&nbsp;<b> 94431 72023/ 90033 54099.</b></label><br>
    <center><span>Assuring Best services at all times.</span></center>
    <div id="btm">
    <span style="text-decoration:underline;float:left;" ><b>TERMS & CONDITIONS</b></span><br>
    <ol style="float: left;">
      <li>Price : Add 18% Taxes.</li>
      <!-- <li>Advanced : 4 months(deposit) </li> -->
      <li>Payment : As per agreement</li>
      <li>Validity : 30 Days</li>
    </ol><br>
    <p style="float: right;">For<label style="font-size: 18px; color:solid blue;">&nbsp;Sakthi Copier</label><br><br><br> <label>Authorised Signature</label></p>
    <img src="lpad_btm.jpg"  alt="">
</div>
</body>
</html>