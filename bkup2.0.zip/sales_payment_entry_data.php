<?php

include 'dbconnect.php';

$object = new db_conn();

$link=$object-> connection();


echo"connected";
$bill_no= $_GET["bill_no"];
$payment_date= $_GET["pay_date"];
$payment_type = $_GET["pay_type"];
$payment_amount = $_GET["pay_amount"];
$remarks = $_GET["remarks"];
$customer_name = $_GET["customer_name"];
// $uname = $_GET["buname"];
// $pwd = $_GET["bpwd"];
// $status = $_GET["bstatus"];
// $group = $_POST["bgroup"];

// echo"Post Data:".$fname;
$sql="insert into tblpayment(pay_billno, pay_date,pay_type,pay_amount,remarks,customer_name)values('$bill_no','$payment_date','$payment_type','$payment_amount','$remarks','$customer_name')";
echo$sql;

$result=mysqli_query($link,$sql);

?>